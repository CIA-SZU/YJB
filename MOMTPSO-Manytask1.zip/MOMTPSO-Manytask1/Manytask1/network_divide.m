function count = network_divide(object,target,n)
    dim1=length(object);
    dim2=size(target,2);
    block=linspace(0,1,n+1);
    count=zeros(1,size(target,1));
    
    if dim1==dim2
        for i=1:size(target,1)
            for j=1:dim1
               for z=1:n
                   %���������������
                   if object(j)>=block(z)&&object(j)<=block(z+1)&&target(i,j)>=block(z)&&target(i,j)<=block(z+1)
                       count(i)=count(i)+1;
                   end
               end
            end
        end
    end
end
