function [data_MFPSO,igd] = MFPSO(Tasks,pop,gen,rmp,index)

    if mod(pop,2) ~= 0
        pop = pop + 1;
    end
    no_of_tasks=length(Tasks);
    if no_of_tasks <= 1
        error('At least 2 tasks required for MFEA');
    end
    oneTask=pop/no_of_tasks; 
    
    nGrid=9; 
    ite = 1;
    pm=0.1;
    wmax=0.1; 
    wmin=0.01;    
    nRep=oneTask;           
    
    c1=0.8*ones(1,no_of_tasks);
    c2=1.6*ones(1,no_of_tasks);
    c3=0.5*ones(1,no_of_tasks);            %ÿ�������c3��һ��
    rmp=rmp*ones(1,no_of_tasks);
    
    D=zeros(1,no_of_tasks);
    for i=1:no_of_tasks
        D(i)=Tasks(i).dim;
    end
    D_multitask=max(D);
    
    %��ʼ����Ⱥ������
    for i = 1 : pop
        population(i) = Particle();
        population(i) = initialize(population(i),D_multitask);
        if mod(i,oneTask)==0
            population(i).skill_factor=floor(i/oneTask);
        else
            population(i).skill_factor=floor(i/oneTask)+1;
        end
    end
    for i = 1 : pop
        population(i) = evaluate(population(i),Tasks(population(i).skill_factor),index);
    end
    
    %��ÿ��������з�֧������
    for i = 1:no_of_tasks
        count_obj = [];
        popobj = [];
        sub_pop=population([population.skill_factor]==i);
        for j = 1:length(sub_pop)
           popobj(j,:) = sub_pop(j).obj;
           sub_pop(j).pbestFitness=sub_pop(j).obj;   %��¼�����ӵ�ǰ������Ŀ��ֵ����һ��Ĭ��Ϊ�ø��屾��   
           sub_pop(j).pbest=sub_pop(j).rnvec; 
        end
        [ ~, FrontNO,~] = NDSort(popobj,inf);
        for j = 1:length(sub_pop)
            sub_pop(j).front = FrontNO(j);
            if FrontNO(j)==1
                sub_pop(j).IsDominated=false;
            else
                sub_pop(j).IsDominated=true;
            end
        end
        
        rep{i}=sub_pop(~[sub_pop.IsDominated]);    %ȡ����֧���
        rep{i}=CreateGrid(rep{i},nGrid);

        for ob=1:length(rep{i})
            count_obj(ob,:)=rep{i}(ob).pbestFitness;
        end
        igd(i,ite)= calculate_IGD(count_obj,index);
        population((i-1) * oneTask +1 : i*oneTask) = sub_pop;
    end
    
    ite=ite+1;
    while ite<=gen

        w1=(wmax - (wmax-wmin)*(ite/gen));

        corr = zeros(no_of_tasks,no_of_tasks);
        for task_i = 1:no_of_tasks
            for task_j = 1:no_of_tasks
                if task_i ~= task_j
                    corr(task_i,task_j) = redVar(rep{task_i},rep{task_j});
                end
            end
        end

        for k=1:no_of_tasks
            sub_pop=population([population.skill_factor]==k);
            if mod(ite,50)==0
               for i = 1:oneTask
                  if rand()<0.1
                      sub_pop(i) = reset(sub_pop(i));
                  end
               end
            end
            for i=1:oneTask
                [leader,~]=SelectLeader(rep{k});        
                otherLeader = SelectLeader2(rep,k,nGrid,no_of_tasks);
                thiscorr = corr(k,otherLeader.skill_factor);
                sub_pop(i)=velocityUpdate(sub_pop(i),leader.pbest,otherLeader,rmp(k),w1,c1(k),c2(k),thiscorr);
            end
            population([population.skill_factor]==k)=sub_pop;
        end
        for i=1:pop
            population(i)=positionUpdate(population(i));
        end
        for i=1:no_of_tasks
           sub_p=population([population.skill_factor]==i);
            for z=1:numel(sub_p)
                temp(z,:)=sub_p(z).pbest;
            end
           standard(i,:)=std(temp,1,1);
           temp=[];
        end
        for i=1:pop
            if rand<pm
                t=population(i).skill_factor;
                population(i).rnvec = Mutate(population(i).rnvec,pm,0,1,standard(t,:));
            end
        end
        for i = 1 : pop
            population(i) = evaluate(population(i),Tasks(population(i).skill_factor),index);
        end
        for i=1:pop
            [population(i),update(i)]=pbestUpdate(population(i));
        end
        for j=1:no_of_tasks
            rep_obj=[];
            popobj=[];
            count_obj=[];
            sub=population([population.skill_factor]==j);
            for i=1:length(sub)
               popobj(i,:)=sub(i).pbestFitness;
            end
            [ ~, FrontNO,~] = NDSort(popobj,inf);
            for k = 1:length(sub)
                sub(k).front = FrontNO(k);
                if FrontNO(k)==1&&update((j-1)*oneTask+k)~=0 
                    sub(k).IsDominated=false;
                else
                    sub(k).IsDominated=true;
                end
            end
            oldNum=numel(rep{j});
            rep{j}=[rep{j},sub(~[sub.IsDominated])];
            for rep_num=1:numel(rep{j})
                rep_obj(rep_num,:)=rep{j}(rep_num).pbestFitness;
            end
            [ ~, rep_FrontNO,~] = NDSort(rep_obj,inf);
            eff_transfer = 0;
            no_transfer = 0;
            for rep_num=1:numel(rep{j})
                if rep_FrontNO(rep_num)==1
                    rep{j}(rep_num).IsDominated=false;
                    if rep_num>oldNum     
                        if rep{j}(rep_num).Strategy ==1
                            eff_transfer = eff_transfer + 1;
                        else
                            no_transfer = no_transfer + 1;
                        end
                    end
                else
                    rep{j}(rep_num).IsDominated=true;
                end
            end
            rep{j}=rep{j}(~[rep{j}.IsDominated]);
            if numel(rep{j})>nRep
                Extra=numel(rep{j})-nRep;
                for e=1:Extra
                    rep{j}=DeleteOneRepMemebr(rep{j});
                end
            end

%             no_transfer_eff = 0;
%             for kki = 1:numel(rep{j})
%                 if rep{j}(kki).Strategy == 0
%                      no_transfer_eff = no_transfer_eff + 1;
%                 end
%                 %�ǵ����ô浵�������ӵ�Strategy
%                 rep{j}(kki).Strategy = -1;
%             end
            rep{j}=CreateGrid(rep{j},nGrid);  
            all_transfer = 0;
            for pop_id = 1:oneTask
                all_transfer = all_transfer + sub(pop_id).Strategy;
            end
            for ob=1:length(rep{j})
                count_obj(ob,:)=rep{j}(ob).pbestFitness;
            end
            x = 10 * (no_transfer)/(oneTask-all_transfer);
            rmp(j) = 1/(2*(1+exp(x)));

            population((j-1) * oneTask +1 : j*oneTask) = sub;
            igd(j,ite)= calculate_IGD(count_obj,index);
        end
        disp(['generation: ',num2str(ite),' problem:',num2str(index),' the best igd:',num2str(igd(1,ite)),' ',num2str(igd(2,ite))]);
        ite=ite+1;
    end    
    
    data_MFPSO=population;
end