
function [leader,sci]=SelectLeader(rep)
    
    if numel(rep)~=1
        GI=[rep.GridIndex];
        OC=unique(GI);
        beta = 2;
        N=zeros(size(OC));
        for k=1:numel(OC)
            N(k)=numel(find(GI==OC(k)));
        end
        P = 1./(N+1);
        P=P/sum(P);
        sci=RouletteWheelSelection(P); 
        sc=OC(sci);
        SCM=find(GI==sc); 
        if length(SCM)==1
            leader=rep(SCM);
        else
            distance=[];
            for i=1:numel(SCM)
                t = SCM(i);
                distance(i)=sqrt(sum(rep(t).pbestFitness.^2));
            end
            maxF=max(distance);
            minF=min(distance);
            if maxF ~= minF
                for i=1:numel(SCM)
                    Chose(i) = exp(beta*(maxF-distance(i))/(maxF-minF));
                end
                Chose = Chose/sum(Chose);
                par = RouletteWheelSelection(Chose);
            else
                par = randi(length(SCM));
            end
            leader=rep(SCM(par));
        end
%         maxF=max(distance);
%         minF=min(distance);
%         
%         if maxF ~= minF
%             for i=1:numel(rep)
%                 this_OC = find(GI==rep(i).GridIndex);
%                 P(i)= exp(-beta*(distance(i)-minF)/(maxF-minF)-length(this_OC));
% %               P(i)=gamma*(sum(pbestFitness(i,:),2)-minF)/maxF+(exp(length(this_OC)));
%             end
%         else
%             for i=1:numel(rep)
%                 P(i)= 1;
%             end
%         end
    else
        leader=rep(1);
        sci=1;
    end
end