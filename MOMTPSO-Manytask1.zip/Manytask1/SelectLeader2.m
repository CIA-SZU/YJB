
function leader=SelectLeader2(rep,k,nGrid,t_num)

    target=randperm(t_num);
    if target(1)==k
       target(1)=target(2);
    end
    original_t = rep{k};
    target_t = rep{target(1)};
    maxNobj = max(length(original_t(1).obj),length(target_t(1).obj));
    
    if numel(target_t) == 1
       leader = target_t(1);
    else
       calParicleNum = zeros(2,power(nGrid+2,maxNobj));
       GI=[target_t.GridIndex];
       OC=unique(GI);
       for k=1:numel(OC)
          calParicleNum(2,OC(k))=numel(find(GI==OC(k)));
       end
       for i = 1:numel(original_t)
           calParicleNum(1,original_t(i).GridIndex) = calParicleNum(1,original_t(i).GridIndex) + 1;
       end
       canChose = find( calParicleNum(2,:) ~= 0 );
       for k = 1:numel(canChose)
            P(k) = 1./(2*calParicleNum(1,canChose(k))+0.001);
       end
       P=P/sum(P);
       sci=RouletteWheelSelection(P);
       sc=canChose(sci);
       SCM=find(GI==sc);  
       if length(SCM)==1
           leader = target_t(SCM);
       else
           par = randi(length(SCM));
           leader = target_t(SCM(par));
       end
    end
end