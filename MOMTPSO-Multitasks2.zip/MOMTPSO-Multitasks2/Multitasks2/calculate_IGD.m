function [value1]=calculate_IGD( PF1,T1_data)
    pf = load(PF1);
    Distance = min(pdist2(pf,T1_data),[],2);
    value1 = mean(Distance);
end

