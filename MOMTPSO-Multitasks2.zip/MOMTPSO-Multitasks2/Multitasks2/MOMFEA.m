function [IGD,population]=MOMFEA(Tasks,pop,rmp,gen,benchMark_num)
task_num=length(Tasks);
for i=1:task_num
    D(i)=Tasks(i).dim;
end
dim=max(D);
id_num = 1;%��ʼ����Ⱥskill_factor
for i=1:pop
    population(i)=Chromosome();
    population(i)=initialize(population(i),dim);
    if i>1 && ~mod(i-1 , pop/task_num)
        id_num = id_num + 1;
    end
    population(i).skill_factor=id_num;
end
%���ۺ���
for i = 1:pop
    [population(i).obj(1) , population(i).obj(2)] = evaluate(population(i),Tasks(population(i).skill_factor), benchMark_num);
end

%��ÿ��������Ⱥ���з�֧������
for i = 1:task_num
    popobj = [];
    population_subpop =population([population.skill_factor]==i);   %ѡ������Ⱥ
    for j = 1:length(population_subpop)
        popobj(j,:) = population_subpop(j).obj;
    end
    [ front, FrontNO,~] = NDSort(popobj,inf);
    for j = 1:length(population_subpop)
        population_subpop(j).front = FrontNO(j);
    end
    %crowing distance
    [population_subpop,~]=SolutionComparison.diversity(population_subpop,front,length(population_subpop...
        ),length(population_subpop(1).obj));
    population((i-1) * (pop/task_num) +1 : i*(pop/task_num)) = population_subpop;
end
mum=20;
muc=20;
for generation=1:gen
    count=1;
    for i=1:2:pop-1 % Create offspring population via mutation and crossover
        child(count)=Chromosome;
        child(count+1)=Chromosome;
        rndlist = randperm(pop);
        p1=rndlist(1);
        p2=rndlist(2);
        if population(p1).skill_factor==population(p2).skill_factor || rand(1)<rmp
            [child(count).rnvec,child(count+1).rnvec]=Evolve.crossover(population(p1).rnvec,population(p2).rnvec,muc,dim);
            child(count).rnvec = Evolve.mutate(child(count).rnvec,mum,dim,1/dim);
            child(count+1).rnvec=Evolve.mutate(child(count+1).rnvec,mum,dim,1/dim);
            %��ֱ�Ļ�����
            if rand(1) < 0.5
                child(count).skill_factor = population(p1).skill_factor;
            else
                child(count).skill_factor = population(p2).skill_factor;
            end
            if rand(1) < 0.5
                child(count+1).skill_factor = population(p1).skill_factor;
            else
                child(count+1).skill_factor = population(p2).skill_factor;
            end
        else
            
            child(count).rnvec = Evolve.mutate(population(p1).rnvec,mum,dim,1/dim);
            child(count+1).rnvec=Evolve.mutate(population(p2).rnvec,mum,dim,1/dim);
            child(count).skill_factor=population(p1).skill_factor;
            child(count+1).skill_factor=population(p2).skill_factor;
            
        end
        count=count+2;
    end
    
    %�Ӵ�����
    for i = 1:pop
        [child(i).obj(1) , child(i).obj(2)] = evaluate(child(i), Tasks(child(i).skill_factor) , benchMark_num);
    end
    
    population=reset(population,pop);%ÿ���һ�ν�����Ҫ���¼����֧������
    intpopulation(1:pop)=population;
    intpopulation(pop+1:2*pop)=child;
    %ȫ��������з�֧������
    for i = 1:task_num
        popobj = [];
        population_subpop = intpopulation([intpopulation.skill_factor]==i);   %ѡ������Ⱥ
        for j = 1:length(population_subpop)
            popobj(j,:) = population_subpop(j).obj;
        end
        [ front, FrontNO,~] = NDSort(popobj,inf);
        for j = 1:length(population_subpop)
            population_subpop(j).front = FrontNO(j);
        end
        
        [population_subpop,~]=SolutionComparison.diversity(population_subpop,front,length(population_subpop...
            ),length(population_subpop(1).obj));
        population((i-1) * (pop/task_num) +1 : i*(pop/task_num)) = population_subpop(1:(pop/task_num));
    end
    
    %   ����ÿһ�������IGD---------------------------
    for i = 1:task_num
        data = vec2mat([population((i-1) * (pop/task_num) +1 : i*(pop/task_num)).obj],2);
        igd = calculate_IGD(data , benchMark_num);
        if  generation == 1
            IGD(i , generation) = igd;
        elseif igd < IGD(i,generation-1)
            IGD(i , generation) = igd;
        else
            IGD(i , generation) = IGD(i,generation - 1);
        end
    end
    
    disp(['new_Generation:' , num2str(generation)]);
end
end