classdef Particle    
    properties
        rnvec; % (genotype)--> decode to find design variables --> (phenotype)
        pbest;
        pbestFitness;
        velocity;
        obj;
        front;%���ڵڼ���
        CD;
        rank;%��ʾ�ǵڼ�������
        Strategy;   %��ȡ���ֲ���
        IsDominated;
        GridIndex;   %���ڵڼ�������
        GridSubIndex;  
        skill_factor;
    end    
    methods        
        function object = initialize(object,D)            
            object.rnvec = rand(1,D);
            object.pbest = object.rnvec;
            object.velocity = zeros(1,D);
        end
        function object = reset(object)
            object.rnvec = rand(1,length(object.rnvec));
        end
        
        % position update
        function object=positionUpdate(object)                       
            object.rnvec=object.rnvec+object.velocity;
            object.rnvec(object.rnvec>1)=1;
            object.velocity(object.rnvec>1)=-5.*object.velocity(object.rnvec>1);
            object.rnvec(object.rnvec<0)=0;
            object.velocity(object.rnvec<0)=-5.*object.velocity(object.rnvec<0);
        end
        
        % ����Ŀ��ֵ,sub_popΪȥ���˵�ǰ���������Ⱥ
        function [object,update]=pbestUpdate(object)
          len = length(object.obj);
          if sum(object.obj<=object.pbestFitness) == len
              object.pbestFitness=object.obj;
              object.pbest=object.rnvec;
              update=1;
          elseif sum(object.obj<=object.pbestFitness) == 0
                update=0;
          else
                if rand< 0.9
                    object.pbestFitness=object.obj;
                    object.pbest=object.rnvec;
                    update=1;
                else
                    update=0;
                end
          end
        end 

        function object=velocityUpdate(object,leader,gbest,rmp,w1,c1,c2,c3)
            len=length(object.velocity);
            if rand()<rmp
                object.Strategy = 1;
                object.velocity = w1*object.velocity+c1*rand(1,len).*(object.pbest-object.rnvec)...
                    +rand(1,len).*(leader-object.rnvec);
                j0=randi([1,length(leader)]);               
                for r=1:length(object.velocity)
                    if j0 ==r || rand(1)<1
                        object.velocity(r)= object.velocity(r) + c3*rand*(gbest.pbest(r)-object.rnvec(r));
                    end
                end
            else
                object.Strategy = 0;
                object.velocity=w1*object.velocity+c1*rand(1,len).*(object.pbest-object.rnvec)...
                    +c2*rand(1,len).*(leader-object.rnvec);
            end
        end
  
    end
end