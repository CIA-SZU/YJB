function [value1]=calculate_IGD( PF1,T1_data)
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%���ݲ�ͬ���������IGD��ֵ
%   �˴���ʾ��ϸ˵��
    pf = load(PF1);
    Distance = min(pdist2(pf,T1_data),[],2);
    value1 = mean(Distance);


%     IGD = 0;
%     if strcmp(PF2,'convex')
%         load convex.pf
%         Distance = min(pdist2(T2_data,convex),[],2);
%         IGD = mean(Distance);
%         value2=IGD;
%     elseif strcmp(PF2,'concave')
%         load concave.pf
%         Distance = min(pdist2(T2_data,concave),[],2);
%         IGD = mean(Distance);
%         value2 = IGD;
%     else%PF��Բ
%         load circle.pf
%         Distance = min(pdist2(T2_data,circle),[],2);
%         IGD = mean(Distance);
%         value2 = IGD;
%     end
end

