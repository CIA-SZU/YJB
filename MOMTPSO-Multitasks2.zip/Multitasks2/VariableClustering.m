function [CV,DV,igd] = VariableClustering(population,nSel,nPer,Task,index,igd,que)
    %nSel = 4, nPer = 50
    M = length(population(1).obj);             %Ŀ�꺯��������
    N = numel(population);                      %��Ⱥ����
    D = length(population(1).rnvec);          %D���߱���ά�ȣ�
    ND = [population.front]==1;
    
    ite = 2;
    
    count = 1;
    for i = 1:N
       if ND(i)==1
            objs(count,:) = population(i).obj;
            count = count + 1;
       end
    end
    
    fmin  = min(objs,[],1);      %�ҵ���֧������С�����Ŀ�꺯��ֵ
    fmax  = max(objs,[],1);
    if any(fmax==fmin)
        fmax = ones(size(fmax));
        fmin = zeros(size(fmin));
    end
    
    Angle  = zeros(D,nSel);
    RMSE   = zeros(D,nSel);
    Sample = randi(N,1,nSel);           %����1*nSel ��С��N����
    
    for k = 1:nSel
        rnvecMatrix(k,:) = population(Sample(k)).rnvec;
    end
    rnvecMatrix = repmat(rnvecMatrix,nPer,1);%���nSel*nPer������
    
    %200�������ٶ�ÿһά���м��㣬һ����200*50������ = 10000������
    for i = 1 : D
       Decs = rnvecMatrix;
       Decs(:,i) = unifrnd(0,1,size(Decs,1),1);
       obj_for_IGD = [];
       for j = 1:size(Decs,1)
          newPopu(j) = Particle(); 
          newPopu(j).rnvec = Decs(j,:);
          newPopu(j) = evaluate(newPopu(j),Task,index);
          obj_for_IGD(j,:) = newPopu(j).obj;
       end
       
      %�ǵü���igd
      igd(que,ite)= calculate_IGD(obj_for_IGD(1:100,:), index);
      ite = ite + 1;
      igd(que,ite)= calculate_IGD(obj_for_IGD(101:200,:), index);
      ite = ite + 1;
      
       for j = 1 : nSel
           Points = [];
           %��j��������ÿ��nSel��һ������
           particle_arr = j:nSel:size(Decs,1);
           for k = 1:length(particle_arr)
               Points(k,:) = newPopu(particle_arr(k)).obj;        
           end
           Points = (Points-repmat(fmin,size(Points,1),1))./repmat(fmax-fmin,size(Points,1),1);
           Points = Points - repmat(mean(Points,1),nPer,1);
           [~,~,V] = svd(Points);
           Vector  = V(:,1)'./norm(V(:,1)');
           error = zeros(1,nPer);
           for k = 1 : nPer
               error(k) = norm(Points(k,:)-sum(Points(k,:).*Vector)*Vector);
           end
           RMSE(i,j) = sqrt(sum(error.^2));
           normal     = ones(1,size(Vector,2));
           sine       = abs(sum(Vector.*normal,2))./norm(Vector)./norm(normal);
           Angle(i,j) = real(asin(sine)/pi*180);
       end
    end
    
    VariableKind = (mean(RMSE,2)<1e-2)';
    result       = kmeans(Angle,2)';
%     if any(result(VariableKind)==1) && any(result(VariableKind)==2)
%         if mean(mean(Angle(result==1&VariableKind,:))) > mean(mean(Angle(result==2&VariableKind,:)))
%             VariableKind = VariableKind & result==1;
%         else
%             VariableKind = VariableKind & result==2;
%         end
%     end
    len1 = sum(result ==1);
    len2 = sum(result ==2);
    if len1<len2
       result = [2*ones(1,len1),ones(1,len2)]; 
    end
    VariableKind = VariableKind == result;
    CV = find(VariableKind);
    DV = find(~VariableKind);
end