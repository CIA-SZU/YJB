function group = overlapGrouping(niv,nov,nsv,nvg,startPos)
    len = zeros(1,nvg);
    pointer = startPos;  %java������Ϊ0
    for i = 1:nvg
       len(i) = niv(i) + nov(i) + nsv;
       group(i,:) = zeros * len(i);
       for j = nov(i)+nsv+1:len(i)
           group(i,j) = pointer;
           pointer = pointer + 1;
       end
    end
    
    for i = 1:nvg
       for j = 1:nov(i)
          if i==1
             group(i,j) = group(nvg,len(nvg)-1-j+1 + 1);
          else
             group(i,j) = group(i-1,len(i-1)-j-1 + 1 + 1);
          end
       end
       for j = 1:nsv
       end       
    end
    
    for j = 1:nsv
       for i = 1:nvg
           group(i,j+nov(i)) = pointer;
       end
       pointer = pointer + 1;
    end
end