function PlotCosts(pop,rep)
    
    pop_costs=[pop.pbestFitness];
    pop_costs=reshape(pop_costs,2,[]);
    plot(pop_costs(1,:),pop_costs(2,:),'ko');
    hold on;
    
    rep_costs=[rep.pbestFitness];
    rep_costs=reshape(rep_costs,2,[]);
    plot(rep_costs(1,:),rep_costs(2,:),'r*');
    
    rep_obj=[pop.obj];
    rep_obj=reshape(rep_obj,2,[]);
    plot(rep_obj(1,:),rep_obj(2,:),'b.');
    
    xlabel('1^{st} Objective');
    ylabel('2^{nd} Objective');
    
    grid on;
    
    hold off;

end