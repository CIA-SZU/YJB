function [Tasks] = benchmark(benchMark_num)
    switch benchMark_num
        %25 - 32 �� 1-8
        case 1
            dim = 50;
            task_num = 5;
            for i = 1 : task_num
                Tasks(i).numberOfObjectives = 2;
                Tasks(i).dim = dim;
                Tasks(i).boundaryCvDv = 1;
                Tasks(i).name = strcat("ETMOF25_", string(i));
                file_dir = strcat(".\MData\benchmark_", string(benchMark_num + 24));
                rotation_file = strcat("\matrix_", string(i));
                Tasks(i).matrix = load(strcat(file_dir, rotation_file));
                Tasks(i).shift = zeros(1,dim - Tasks(i).boundaryCvDv);
                Tasks(i).genType = "addition";
                Tasks(i).hType = "convex";
                Tasks(i).PFfile = strcat('.\pf\StaticPF\',Tasks(i).hType,'_',string(Tasks(i).numberOfObjectives),'D.pf');
            end
%             Tasks(1).PF = 'circle';
            Tasks(1).Low = [0,-10*ones(1,49)];
            Tasks(1).Upper = [1,10*ones(1,49)];
            Tasks(1).gType = "LF1";
            Tasks(2).Low = [0,-5*ones(1,49)];
            Tasks(2).Upper = [1,5*ones(1,49)];
            Tasks(2).gType = "LF2";
            Tasks(3).Low = [0,-1*ones(1,49)];
            Tasks(3).Upper = [1,1*ones(1,49)];
            Tasks(3).gType = "LF3";
            Tasks(4).Low = [0,-5*ones(1,49)];
            Tasks(4).Upper = [1,5*ones(1,49)];
            Tasks(4).gType = "LF4_5";
            Tasks(5).Low = [0,-10*ones(1,49)];
            Tasks(5).Upper = [1,10*ones(1,49)];
            Tasks(5).gType = "LF7";
         case 2
            dim = 50;
            task_num = 10;
            for i = 1 : task_num
                if mod(i,5) == 1
                    Tasks(i).gType = "LF1";
                    Tasks(i).Low = [0,-10*ones(1,49)];
                    Tasks(i).Upper = [1,10*ones(1,49)];
                elseif mod(i,5) == 2
                    Tasks(i).gType = "LF2";
                    Tasks(i).Low = [0,-5*ones(1,49)];
                    Tasks(i).Upper = [1,5*ones(1,49)];
                elseif mod(i,5) == 3
                    Tasks(i).gType = "LF3";
                    Tasks(i).Low = [0,-1*ones(1,49)];
                    Tasks(i).Upper = [1,1*ones(1,49)];
                elseif mod(i,5) == 4
                    Tasks(i).gType = "LF4_5";
                    Tasks(i).Low = [0,-5*ones(1,49)];
                    Tasks(i).Upper = [1,5*ones(1,49)];
                else
                    Tasks(i).gType = "LF7";
                    Tasks(i).Low = [0,-10*ones(1,49)];
                    Tasks(i).Upper = [1,10*ones(1,49)];
                end
                Tasks(i).numberOfObjectives = 2;
                Tasks(i).dim = dim;
                Tasks(i).boundaryCvDv = 1;
                Tasks(i).name = strcat("ETMOF26_", string(i));
                file_dir = strcat(".\MData\benchmark_", string(benchMark_num + 24));
                rotation_file = strcat("\matrix_", string(i));
                Tasks(i).matrix = load(strcat(file_dir, rotation_file));
%                 shift_file = strcat("\bias_", string(i));
                Tasks(i).shift = zeros(1,Tasks(i).dim - Tasks(i).boundaryCvDv);
                Tasks(i).genType = "multiplication";
                if mod(i,2) == 1
                    Tasks(i).genType = "addition";
                end
                if mod(i,3) == 1
                    Tasks(i).hType = "convex";
                elseif mod(i,3) == 2
                    Tasks(i).hType = "concave";
                else
                    Tasks(i).hType = "lineoid";
                end
                Tasks(i).PFfile = strcat('.\pf\StaticPF\',Tasks(i).hType,'_',string(Tasks(i).numberOfObjectives),'D.pf');
            end
         case 3
            dim = 50;
            task_num = 10;
            for i = 1 : task_num
                if mod(i,5) == 1
                    Tasks(i).gType = "DF14";
                    Tasks(i).Low = [0,0,-10*ones(1,48)];
                    Tasks(i).Upper = [1,1,10*ones(1,48)];
                elseif mod(i,5) == 2
                    Tasks(i).gType = "DF15";
                    Tasks(i).Low = [0,0,-10*ones(1,48)];
                    Tasks(i).Upper = [1,1,10*ones(1,48)];
                elseif mod(i,5) == 3
                    Tasks(i).gType = "DF16";
                    Tasks(i).Low = [0,0,-10*ones(1,48)];
                    Tasks(i).Upper = [1,1,10*ones(1,48)];
                elseif mod(i,5) == 4
                    Tasks(i).gType = "DF17";
                    Tasks(i).Low = [0,0,-10*ones(1,48)];
                    Tasks(i).Upper = [1,1,10*ones(1,48)];
                else
                    Tasks(i).gType = "DF18";
                    Tasks(i).Low = [0,0,-10*ones(1,48)];
                    Tasks(i).Upper = [1,1,10*ones(1,48)];
                end
                Tasks(i).numberOfObjectives = 3;
                Tasks(i).dim = dim;
                Tasks(i).boundaryCvDv = 2;
                Tasks(i).name = strcat("ETMOF27_", string(i));
                Tasks(i).hType = "lineoid";
                Tasks(i).matrix = eye(Tasks(i).dim-Tasks(i).boundaryCvDv);
                Tasks(i).shift = zeros(1,Tasks(i).dim - Tasks(i).boundaryCvDv);
                Tasks(i).genType = "multiplication";
                Tasks(i).PFfile = strcat('.\pf\StaticPF\',Tasks(i).hType,'_',string(Tasks(i).numberOfObjectives),'D.pf');
%                 if i<=6   %�������⼯Ӧ����6���������
                if i <= 5
                    Tasks(i).genType = "multiplication";
                    Tasks(i).linkageType = "linear";
                else
                    Tasks(i).genType = "addition";
                    Tasks(i).linkageType = "nonlinear";
                end
                Tasks(i).gp = [];
                Tasks(i).dgd = {};
                Tasks(i) = getTaskInfo(Tasks(i),-10,10);
            end
        case 4
            dim = 51;
            task_num = 20;
            for i = 1 : task_num
                if mod(i,5) == 1
                    Tasks(i).gType = "F1";
                    Tasks(i).Low = [0,0,-50*ones(1,49)];
                    Tasks(i).Upper = [1,1,50*ones(1,49)];
                elseif mod(i,5) == 2
                    Tasks(i).gType = "F5";
                    Tasks(i).Low = [0,0,-10*ones(1,49)];
                    Tasks(i).Upper = [1,1,10*ones(1,49)];
                elseif mod(i,5) == 3
                    Tasks(i).gType = "F6";
                    Tasks(i).Low = [0,0,-20*ones(1,49)];
                    Tasks(i).Upper = [1,1,20*ones(1,49)];
                elseif mod(i,5) == 4
                    Tasks(i).gType = "F8";
                    Tasks(i).Low = [0,0,-30*ones(1,49)];
                    Tasks(i).Upper = [1,1,30*ones(1,49)];
                else
                    Tasks(i).gType = "F9";
                    Tasks(i).Low = [0,0,-40*ones(1,49)];
                    Tasks(i).Upper = [1,1,40*ones(1,49)];
                end
                Tasks(i).numberOfObjectives = 3;
                Tasks(i).dim = dim;
                Tasks(i).boundaryCvDv = 2;
                Tasks(i).name = strcat("ETMOF28_", string(i));
                file_dir = strcat(".\MData\benchmark_", string(benchMark_num + 24));
                rotation_file = strcat("\matrix_", string(i));
                Tasks(i).matrix = load(strcat(file_dir, rotation_file));
%                 shift_file = strcat("\bias_", string(i));
                Tasks(i).shift = zeros(1,Tasks(i).dim - Tasks(i).boundaryCvDv);
                Tasks(i).genType = "multiplication";
                if mod(i,2) == 1
                    Tasks(i).genType = "addition";
                end
                if mod(i,3) == 1
                    Tasks(i).hType = "lineoid";
                elseif mod(i,3) == 2
                    Tasks(i).hType = "sphere";
                else
                    Tasks(i).hType = "convex";
                end
                Tasks(i).PFfile = strcat('.\pf\StaticPF\',Tasks(i).hType,'_',string(Tasks(i).numberOfObjectives),'D.pf');
            end
        case 5
            dim = 51;           %MMIDTLZ
            task_num = 30;
            for i = 1 : task_num
                if mod(i,3) == 1
                    Tasks(i).gType = "F1";
                    Tasks(i).Low = [0,0,-50*ones(1,49)];
                    Tasks(i).Upper = [1,1,50*ones(1,49)];
                elseif mod(i,3) == 2
                    Tasks(i).gType = "F9";
                    Tasks(i).Low = [0,0,-100*ones(1,49)];
                    Tasks(i).Upper = [1,1,100*ones(1,49)];
                else
                    Tasks(i).gType = "F6";
                    Tasks(i).Low = [0,0,-0.5*ones(1,49)];
                    Tasks(i).Upper = [1,1,0.5*ones(1,49)];
                end
                Tasks(i).numberOfObjectives = 3;
                Tasks(i).dim = dim;
                Tasks(i).boundaryCvDv = 2;
                Tasks(i).name = strcat("ETMOF29_", string(i));
                file_dir = strcat(".\MData\benchmark_", string(benchMark_num + 24));
                rotation_file = strcat("\matrix_", string(i));
                Tasks(i).matrix = load(strcat(file_dir, rotation_file));
                shift_file = strcat("\bias_", string(i));
                Tasks(i).shift =  load(strcat(file_dir, shift_file));
                Tasks(i).genType = "multiplication";
                if mod(i,2) == 1
                    Tasks(i).hType = "inverted_lineoid";
                else
                    Tasks(i).hType = "inverted_sphere";
                end
                Tasks(i).PFfile = strcat('.\pf\StaticPF\',Tasks(i).hType,'_',string(Tasks(i).numberOfObjectives),'D.pf');
            end
        case 6
            dim = 50;           %MMZDT
            task_num = 40;
            for i = 1 : task_num
                if mod(i,5) == 1
                    Tasks(i).gType = "F5";
                    Tasks(i).Low = [0,-50*ones(1,49)];
                    Tasks(i).Upper = [1,50*ones(1,49)];
                elseif mod(i,5) == 2
                    Tasks(i).gType = "F6";
                    Tasks(i).Low = [0,-50*ones(1,49)];
                    Tasks(i).Upper = [1,50*ones(1,49)];
                elseif mod(i,5) == 3
                    Tasks(i).gType = "F9";
                    Tasks(i).Low = [0,-50*ones(1,49)];
                    Tasks(i).Upper = [1,50*ones(1,49)];
                elseif mod(i,5) == 4
                    Tasks(i).gType = "F7";
                    Tasks(i).Low = [0,-100*ones(1,49)];
                    Tasks(i).Upper = [1,100*ones(1,49)];
                else
                    Tasks(i).gType = "F8";
                    Tasks(i).Low = [0,-0.5*ones(1,49)];
                    Tasks(i).Upper = [1,0.5*ones(1,49)];
                end
                Tasks(i).numberOfObjectives = 2;
                Tasks(i).dim = dim;
                Tasks(i).boundaryCvDv = 1;
                Tasks(i).name = strcat("ETMOF30_", string(i));
                file_dir = strcat(".\MData\benchmark_", string(benchMark_num + 24));
                rotation_file = strcat("\matrix_", string(i));
                Tasks(i).matrix = load(strcat(file_dir, rotation_file));
                shift_file = strcat("\bias_", string(i));
                Tasks(i).shift =  load(strcat(file_dir, shift_file));
                Tasks(i).genType = "multiplication";
                Tasks(i).hType = "convex";
                Tasks(i).PFfile = strcat('.\pf\StaticPF\',Tasks(i).hType,'_',string(Tasks(i).numberOfObjectives),'D.pf');
            end
        case 7
            dim = 50;           %MMLZ
            task_num = 50;
            for i = 1 : task_num
                if mod(i,6) == 1
                    Tasks(i).gType = "LF1";
                    Tasks(i).Low = [0,-60*ones(1,49)];
                    Tasks(i).Upper = [1,60*ones(1,49)];
                elseif mod(i,6) == 2
                    Tasks(i).gType = "LF2";
                    Tasks(i).Low = [0,-50*ones(1,49)];
                    Tasks(i).Upper = [1,50*ones(1,49)];
                elseif mod(i,6) == 3
                    Tasks(i).gType = "LF3";
                    Tasks(i).Low = [0,-40*ones(1,49)];
                    Tasks(i).Upper = [1,40*ones(1,49)];
                elseif mod(i,6) == 4
                    Tasks(i).gType = "LF8";
                    Tasks(i).Low = [0,-30*ones(1,49)];
                    Tasks(i).Upper = [1,30*ones(1,49)];
                elseif mod(i,6) == 5
                    Tasks(i).gType = "LF9";
                    Tasks(i).Low = [0,-20*ones(1,49)];
                    Tasks(i).Upper = [1,20*ones(1,49)];
                else
                    Tasks(i).gType = "LF7";
                    Tasks(i).Low = [0,-10*ones(1,49)];
                    Tasks(i).Upper = [1,10*ones(1,49)];
                end
                Tasks(i).numberOfObjectives = 2;
                Tasks(i).dim = dim;
                Tasks(i).boundaryCvDv = 1;
                Tasks(i).name = strcat("ETMOF31_", string(i));
                file_dir = strcat(".\MData\benchmark_", string(benchMark_num + 24));
                rotation_file = strcat("\matrix_", string(i));
                Tasks(i).matrix = load(strcat(file_dir, rotation_file));
                Tasks(i).shift =  zeros(1,Tasks(i).dim - Tasks(i).boundaryCvDv);
                Tasks(i).genType = "addition";
                Tasks(i).hType = "concave";
                Tasks(i).PFfile = strcat('.\pf\StaticPF\',Tasks(i).hType,'_',string(Tasks(i).numberOfObjectives),'D.pf');
            end
         case 8
            dim = 80;
            task_num = 28;
            for i = 1 : task_num
                if mod(i,14) == 1
                    Tasks(i).gType = "DF1";
                    Tasks(i).Low = [0,0,-10*ones(1,48)];
                    Tasks(i).Upper = [1,1,10*ones(1,48)];
                elseif mod(i,14) == 2
                    Tasks(i).gType = "DF19";
                    Tasks(i).Low = [0,0,-10*ones(1,48)];
                    Tasks(i).Upper = [1,1,10*ones(1,48)];
                elseif mod(i,14) == 3
                    Tasks(i).gType = "DF20";
                    Tasks(i).Low = [0,0,-10*ones(1,48)];
                    Tasks(i).Upper = [1,1,10*ones(1,48)];
                elseif mod(i,14) == 4
                    Tasks(i).gType = "DF21";
                    Tasks(i).Low = [0,0,-10*ones(1,48)];
                    Tasks(i).Upper = [1,1,10*ones(1,48)];
                elseif mod(i,14) == 5
                    Tasks(i).gType = "DF14";
                    Tasks(i).Low = [0,0,-10*ones(1,48)];
                    Tasks(i).Upper = [1,1,10*ones(1,48)];
                elseif mod(i,14) == 6
                    Tasks(i).gType = "DF15";
                    Tasks(i).Low = [0,0,-10*ones(1,48)];
                    Tasks(i).Upper = [1,1,10*ones(1,48)];
                elseif mod(i,14) == 7
                    Tasks(i).gType = "DF16";
                    Tasks(i).Low = [0,0,-10*ones(1,48)];
                    Tasks(i).Upper = [1,1,10*ones(1,48)];
                elseif mod(i,14) == 8
                    Tasks(i).gType = "DF17";
                    Tasks(i).Low = [0,0,-10*ones(1,48)];
                    Tasks(i).Upper = [1,1,10*ones(1,48)];
                elseif mod(i,14) == 9
                    Tasks(i).gType = "DF18";
                    Tasks(i).Low = [0,0,-10*ones(1,48)];
                    Tasks(i).Upper = [1,1,10*ones(1,48)];
                elseif mod(i,14) == 10
                    Tasks(i).gType = "DF22";
                    Tasks(i).Low = [0,0,-10*ones(1,48)];
                    Tasks(i).Upper = [1,1,10*ones(1,48)];
                elseif mod(i,14) == 11
                    Tasks(i).gType = "DF23";
                    Tasks(i).Low = [0,0,-10*ones(1,48)];
                    Tasks(i).Upper = [1,1,10*ones(1,48)];
                elseif mod(i,14) == 12
                    Tasks(i).gType = "DF24";
                    Tasks(i).Low = [0,0,-10*ones(1,48)];
                    Tasks(i).Upper = [1,1,10*ones(1,48)];
                elseif mod(i,14) == 13
                    Tasks(i).gType = "DF25";
                    Tasks(i).Low = [0,0,-10*ones(1,48)];
                    Tasks(i).Upper = [1,1,10*ones(1,48)];
                else
                    Tasks(i).gType = "DF2";
                    Tasks(i).Low = [0,0,-10*ones(1,48)];
                    Tasks(i).Upper = [1,1,10*ones(1,48)];
                end
                Tasks(i).numberOfObjectives = 3;
                Tasks(i).dim = dim;
                Tasks(i).boundaryCvDv = 2;
                Tasks(i).name = strcat("ETMOF32_", string(i));
                Tasks(i).hType = "sphere";
                Tasks(i).matrix = eye(Tasks(i).dim-Tasks(i).boundaryCvDv);
                Tasks(i).shift = zeros(1,Tasks(i).dim - Tasks(i).boundaryCvDv);
                Tasks(i).genType = "multiplication";
%                 if i<=6   %�������⼯Ӧ����6���������
                Tasks(i).genType = "multiplication";
                if i <= 14
                    Tasks(i).linkageType = "linear";
                else
                    Tasks(i).linkageType = "nonlinear";
                end
                Tasks(i).PFfile = strcat('.\pf\StaticPF\',Tasks(i).hType,'_',string(Tasks(i).numberOfObjectives),'D.pf');
                Tasks(i).gp = [];
                Tasks(i).dgd = {};
                Tasks(i) = getTaskInfo(Tasks(i),-10,10);
            end        
    end
end