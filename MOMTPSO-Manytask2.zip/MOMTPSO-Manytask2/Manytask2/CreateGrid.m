function pop=CreateGrid(pop,nGrid)
        c=[pop.pbestFitness];             %��ÿ��Ŀ��ֵȡ����
        nObj = length(pop(1).pbestFitness);
        c=reshape(c,nObj,[]);
        
     if nObj == 2
        Grid = linspace(0,90,nGrid+1);
        %��һ��
        normalize_c(1,:) = myselfnom(c(1,:));
        normalize_c(2,:) = myselfnom(c(2,:));
    
        %Ϊ�������ӷ���index
        for rep_i = 1:numel(pop)
            obj = normalize_c(:,rep_i);
            if obj(1)==0
                angle = 90;
            else
                angle = atand(obj(2)/obj(1));   %���������x��ļн�
            end
            for i = 1:nGrid
               if angle>=Grid(i) && angle<=Grid(i+1)
                  pop(rep_i).GridIndex = i;
                  break
               end
            end
        end
    elseif nObj == 3
        %3ά��Ŀ��
        normalize_c(1,:) = myselfnom(c(1,:));
        normalize_c(2,:) = myselfnom(c(2,:));
        normalize_c(3,:) = myselfnom(c(3,:));

        for rep_i = 1:numel(pop)
            obj = normalize_c(:,rep_i);
            if obj(1)^2 + obj(2)^2 == 0
                angle(1) = 90;
            else
                angle(1) = atand(obj(3)/(sqrt(obj(1)^2 + obj(2)^2)));
            end
            if obj(1)^2 + obj(3)^2 == 0
                angle(2) = 90;
            else
                angle(2) = atand(obj(2)/(sqrt(obj(1)^2 + obj(3)^2)));
            end
            if obj(2)^2 + obj(3)^2 == 0
                angle(3) = 90;
            else
                angle(3) = atand(obj(1)/(sqrt(obj(2)^2 + obj(3)^2)));
            end

            if angle(1)>=60
                pop(rep_i).GridIndex = 1;
            elseif angle(1)>=30 && angle(1) < 60 && angle(2) < 30 && angle(3)>=30 && angle(3) <60
                pop(rep_i).GridIndex = 2;
            elseif angle(1)>=30 && angle(1) < 60 && angle(2) < 30 && angle(3)<30
                pop(rep_i).GridIndex = 3;
            elseif angle(1)>=30 && angle(1) < 60 && angle(2) >= 30 && angle(2) < 60 && angle(3)<30
                pop(rep_i).GridIndex = 4;
            elseif angle(1)< 30 && angle(2) < 30 && angle(3)>=60
                pop(rep_i).GridIndex = 5;
            elseif angle(1)< 30 && angle(2) < 30 && angle(3)>=30 && angle(3)<60
                pop(rep_i).GridIndex = 6;
            elseif angle(1)< 30 && angle(2) >= 30 && angle(2)< 60 && angle(3)<60 && angle(3)>30
                pop(rep_i).GridIndex = 7;
            elseif angle(1)< 30 && angle(2) >= 30 && angle(2)< 60 && angle(3)<30
                pop(rep_i).GridIndex = 8; 
            elseif angle(1)< 30 && angle(2) >= 60 && angle(3)<30
                pop(rep_i).GridIndex = 9;
            else
                pop(rep_i).GridIndex = randi(nGrid);
            end
        end

    end 
end