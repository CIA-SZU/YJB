clear;
beep off
warning off
global evaluation
global maxevaluation
maxevaluation = 5e6;
evaluation = 0;
pop=5000;
rmp=0.5;
gen=1000;
for index =1:8
    Tasks=benchmark(index);
    for run=1:10
        pop = length(Tasks) * 100;
%         [MOMFEAIGD{index,run} , population{index,run}] =  MOMFEA(Tasks,pop,rmp,gen,index);
        [data_MFPSO{index,run},igd{index,run}]=MFPSO(Tasks,pop,gen,rmp,index);
        evaluation = 0;
    end
end

result = zeros(3,8);
for i = 1:30
   for j = 1:length(que)
      result(1:length(min(igd{que(j),i},[],2)),que(j)) = result(1:length(min(igd{que(j),i},[],2)),que(j)) + min(igd{que(j),i},[],2);
   end
end
result = result./i;
save('MOMTPSO-many2','igd');