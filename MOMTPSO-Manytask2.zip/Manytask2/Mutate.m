function xnew=Mutate(x,pm,VarMin,VarMax,standard)
    
    %variance��ʾ����Ⱥ��ÿ�������ķ���
%     nVar=numel(x);
%     j=randi([1 nVar]);
    [~,j]=min(standard);
%     j=1;
    dx=pm*(VarMax-VarMin);
    
    lb=x(j)-dx;
    if lb<VarMin
        lb=VarMin;
    end
    
    ub=x(j)+dx;
    if ub>VarMax
        ub=VarMax;
    end
    
    xnew=x;
    xnew(j)=unifrnd(lb,ub);

end

% function rnvec=Mutate(p,mum,dim,prob_mut,standard)
%     rnvec=p;
%     for i=1:dim
%         if rand(1)<prob_mut
%             u=rand(1);
%             if u <= 0.5
%                 del=(2*u)^(1/(1+mum)) - 1;
%                 rnvec(i)=p(i) + del*(p(i));
%             else
%                 del= 1 - (2*(1-u))^(1/(1+mum));
%                 rnvec(i)=p(i) + del*(1-p(i));
%             end
%         end
%     end            
% end


