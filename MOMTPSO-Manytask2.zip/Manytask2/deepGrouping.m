function deepGroup = deepGrouping(group,a,d)
%The first term of the arithmetic sequence is a, and the tolerance is d
    span = a;
    group(group == 0)= [];        %ȥ��Ϊ0��Ԫ��
    remain = length(group);
    t = 1;
    dg ={};
    cout = 1;
    
    while (remain>span + a)
        g = [];
        for i = 1:span
           g(i) = group(t);
           t = t + 1;
        end
        dg{cout} = g;
        cout = cout + 1;
        remain = remain -span;
        span = span + d;
    end
    

    if remain>0
       g = [];
       for i = 1:remain
          g(i) =  group(t);
          t = t+1;
       end
       dg{cout} = g;
    end
    
    size = length(dg);
    for i = 1:size
       for j = 1:length(dg{i})
          deepGroup(i,j) = dg{i}(j);
       end
    end

end