
function corr = redVar(pop1,pop2)
    len = min(length(pop1(1).pbest),length(pop2(1).pbest));
    for i = 1:length(pop1)
       pbest_one(i,:) = pop1(i).pbest(1:len); 
    end
    for i = 1:length(pop2)
       pbest_two(i,:) = pop2(i).pbest(1:len); 
    end
    meanPbestOne = mean(pbest_one,1);
    meanPbestTwo = mean(pbest_two,1);
    maxDistance1 = sqrt(var(pdist2(meanPbestOne,pbest_one)));
    twoCenteDistance = pdist2(meanPbestOne,meanPbestTwo);
    corr = 1/exp(maxDistance1+twoCenteDistance);
    if corr<0.1
        corr = 0.1;
    end
end
