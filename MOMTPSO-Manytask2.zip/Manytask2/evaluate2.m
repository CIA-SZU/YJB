function object = evaluate2(object,Task,problem)
    %problem �����������⼯�����
    Xcov = object.rnvec;
    Xcov = (Task.Upper - Task.Low).* Xcov + Task.Low;

    x1 = Xcov(1:Task.boundaryCvDv);
    x2 = Xcov(Task.boundaryCvDv+1:end);
    decodeXcov = (x2 - Task.shift) * Task.matrix';   %x2
    decodeXcov = boundaryPrevent(decodeXcov, Task.Low(Task.boundaryCvDv + 1:end) , ...
            Task.Upper(Task.boundaryCvDv + 1:end));
    if problem <=2 || problem == 7         %MMLZ
        quotient = floor((Task.dim - Task.numberOfObjectives+1)/Task.numberOfObjectives);
    %     remainder = mod((Task.dim - Task.numberOfObjectives+1),Task.numberOfObjectives);
        x3 = NaN(Task.numberOfObjectives,quotient+1);          %java�ǿ��������ǲ�һ����С��
        index = zeros(Task.numberOfObjectives,quotient+1);
        for i = 1:Task.numberOfObjectives
           t = 1;
           for j = i:Task.numberOfObjectives:length(decodeXcov)
               x3(i,t) = decodeXcov(j);
               index(i,t) = j + Task.numberOfObjectives - 1;
               t = t + 1;          
           end
        end

        h = evalH(Xcov(1:Task.boundaryCvDv),Task);
        g = evalG(x1,x3,index,Task);
        if strcmp(Task.genType, 'addition')
            object.obj = h + g;
        elseif strcmp(Task.genType, 'multiplication')
            object.obj = h .* ( 1 + g);
        end
    elseif problem == 3 || problem == 8   %MMLMOP
        for i = 1:Task.numberOfObjectives-1
            for j = 1:length(Task.gp(i,:))
                XI(i,j) = Xcov(Task.gp(i,j)+1);     %������0��java�Ǵ�0��ʼ��
            end
        end
        for i = 1:Task.numberOfObjectives-1
           y(i) = abs(sum(XI(i,:)))/length(XI(i,:));
        end
        for i = 1:Task.numberOfObjectives
            for j = 1:size(Task.dgd{i},1)
                temp = Task.dgd{i}(j,:);
                temp = temp(temp ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k = 1:length(temp)
                    xII{i}(j,k) = Xcov(Task.dgd{i}(j,k)+1);
                end
            end
        end
        h = evalHMMLMOP(Task,y);
        g = evalG(Xcov(1),xII,problem,Task);
        if strcmp(Task.genType, 'addition')
            object.obj = h + g;
        elseif strcmp(Task.genType, 'multiplication')
            object.obj = h .* ( 1 + g);
        end
    elseif problem == 4         %MMDTLZ
        g = evalG(decodeXcov,NaN,NaN,Task);
        h = evalH2(x1,g,Task);
        if strcmp(Task.genType, 'addition')
            object.obj = h + g;
        elseif strcmp(Task.genType, 'multiplication')
            object.obj = h * ( 1 + g);
        end
    elseif problem == 5       %MMIDTLZ
        h = evalHMMIDTLZ(Task,x1);
        g = evalG(decodeXcov,NaN,NaN,Task);
        object.obj = h .* ( 1 + g);
    elseif problem == 6         %MMZDT
        f1 = evalF1(x1,'linear');
        g = evalG(decodeXcov,NaN,NaN,Task) + 1;
        f2 = g * evalHMMZDT(f1,g,Task);
        object.obj = [f1,f2];
    end
end


function Gvalue = evalG(x1,x3,index,Task)
    switch Task.gType
        case 'LF1'
            Gvalue = getLF1(x1,x3,index,Task.dim);
        case 'LF2'
            Gvalue = getLF2(x1,x3,index,Task.dim);
        case 'LF3'
            Gvalue = getLF3(x1,x3,index,Task.dim);
        case 'LF4_5'
            Gvalue = getLF4_5(x1,x3,index,Task.dim);
        case 'LF6'
            Gvalue = getLF6(x1,x3,index,Task.dim);
        case 'LF7'
            Gvalue = getLF7(x1,x3,index,Task.dim);
        case 'LF8'
            Gvalue = getLF8(x1,x3,index,Task.dim);
        case 'LF9'
            Gvalue = getLF9(x1,x3,index,Task.dim);
        case 'HF1'
            Gvalue = getHF1(x1);
        case 'HF2'
            Gvalue = getHF2(x1);
        case 'DF1'
            Gvalue = getDF1(x1,x3,Task);
        case 'DF2'
            Gvalue = getDF2(x1,x3,Task);
        case 'DF14'
            Gvalue = getDF14(x1,x3,Task);
        case 'DF15'
            Gvalue = getDF15(x1,x3,Task);
        case 'DF16'
            Gvalue = getDF16(x1,x3,Task);
        case 'DF17'
            Gvalue = getDF17(x1,x3,Task);
        case 'DF18'
            Gvalue = getDF18(x1,x3,Task);
        case 'DF19'
            Gvalue = getDF19(x1,x3,Task);
        case 'DF20'
            Gvalue = getDF20(x1,x3,Task);
        case 'DF21'
            Gvalue = getDF21(x1,x3,Task);
        case 'DF22'
            Gvalue = getDF22(x1,x3,Task);
        case 'DF23'
            Gvalue = getDF23(x1,x3,Task);
        case 'DF24'
            Gvalue = getDF24(x1,x3,Task);
        case 'DF25'
            Gvalue = getDF25(x1,x3,Task);
        case 'F1'
            Gvalue = getF1(x1);
        case 'F5'
            Gvalue = getF5(x1);
        case 'F6'
            Gvalue = getF6(x1);
        case 'F7'
            Gvalue = getF7(x1);
        case 'F8'
            Gvalue = getF8(x1);
        case 'F9'
            Gvalue = getF9(x1);
    end

end

function f1 = evalF1(x1,f1Type)
    if strcmp(f1Type, 'linear')
        sum = 0;
        for i = 1:length(x1)
           sum = sum + x1(i); 
        end
        sum = sum/length(x1);
        f1 = sum;
    elseif strcmp(f1Type, 'nonlinear')
        r = 0;
        for i = 1:length(x1)
           r = r + x1(i)^2;
        end
        r = sqrt(r);
        f1 = 1 - exp(-4*r) * power(sin(5*3.141592653589793*r),4);
    end 
end

function f2 = evalHMMZDT(a,b,Task)
    if strcmp(Task.hType, 'convex')
        f2 = 1 - power(a/b,0.5);
    else
        f2 = 1 - power(a/b,2);
    end
end

function g = getF1(x2)
    Fstar=0.0;
    g = getSphere(x2) + Fstar;
end

function g = getF5(x2)
    Fstar=0.0;
    g = getRosenbrock(x2) + Fstar;
end

function g = getF6(x2)
    Fstar=0.0;
    g = getAckley(x2) + Fstar;
end

function g = getF7(x2)
    Fstar=0.0;
    g = getWeierstrass(x2) + Fstar;
end

function g = getF8(x2)
    Fstar=0.0;
    g = getGriewank(x2) + Fstar;
end

function g = getF9(x2)
    Fstar=0.0;
    g = getRastrigin(x2) + Fstar;
end

function g = getLF1(x1,x3,index,D)
    nObj = size(x3,1);
    g = zeros(1,nObj);
    for i = 1:nObj
       g(i) = 0.0;
       len = sum(~isnan(x3(i,:)));
       for j = 1:len
           if isnan(x3(i,j))
               continue;
           end
           linkages  = (0.3*x1(1)*x1(1)*cos(24*3.141592653589793*x1(1) + 4 *(index(i,j)*3.141592653589793)/D) + 0.6 * x1(1))...
               *sin(6*3.141592653589793 * x1(1) + (index(i,j)*3.141592653589793)/D);
           g(i) = g(i) + (x3(i,j)-linkages)^2; 
       end
       g(i) = 2 * g(i) / len ;
    end
end

function g = getLF2(x1,x3,index,D)
    nObj = size(x3,1);
    g = zeros(1,nObj);
    for i = 1:nObj
       g(i) = 0.0;
       len = sum(~isnan(x3(i,:)));
       for j = 1:len
           if isnan(x3(i,j))
               continue;
           end
           linkages  = x3(i,j) - power(x1(1),0.5*(1.0 + (3.0*(index(i,j)-2)/(D-2))));
           g(i) = g(i) + linkages^2; 
       end
       g(i) = 2 * g(i) / len ;
    end
end

function g = getLF3(x1,x3,index,D)
    nObj = size(x3,1);
    g = zeros(1,nObj);
    for i = 1:nObj
       g(i) = 0.0;
       part1 = 0.0;
       part2 = 1.0;
       len = sum(~isnan(x3(i,:)));
       for j = 1:len
           if isnan(x3(i,j))
               continue;
           end
           linkages  = x3(i,j) - power(x1(1),0.5*(1.0 + (3.0*(index(i,j)-2)/(D-2))));
           part1 = part1 + linkages * linkages;
           part2 = part2 * cos(20*3.141592653589793*linkages/sqrt(index(i,j)));
       end
       g(i) = 4 * part1 - 2 * part2 + 2;
       g(i) = 2 * g(i) / len ;
    end
end

function g = getLF4_5(x1,x3,index,D)
    nObj = size(x3,1);
    g = zeros(1,nObj);
    for i = 1:nObj
       g(i) = 0.0;
       len = sum(~isnan(x3(i,:)));
       for j = 1:len
           if isnan(x3(i,j))
               continue;
           end
           if mod(i,2) == 1
                linkages  = 0.8 * x1(1) * cos(6*3.141592653589793*x1(1) + (index(i,j)*3.141592653589793)/D);
           else
                linkages  = 0.8 * x1(1) * sin(6*3.141592653589793*x1(1) + (index(i,j)*3.141592653589793)/D);
           end
           g(i) = g(i) + (x3(i,j) - linkages)^2;
       end
       g(i) = 2 * g(i) / len ;
    end
end

function g = getLF6(x1,x3,index,D)
    nObj = size(x3,1);
    g = zeros(1,nObj);
    for i = 1:nObj
       g(i) = 0.0;
       len = sum(~isnan(x3(i,:)));
       for j = 1:len
           if isnan(x3(i,j))
               continue;
           end
           linkages  = 2.0 * x1(2) * sin(2*3.141592653589793*x1(1) + (index(i,j)*3.141592653589793)/D);
           g(i) = g(i) + (x3(i,j) - linkages)^2;
       end
       g(i) = 2 * g(i) / len ;
    end
end

function g = getLF7(x1,x3,index,D)
    nObj = size(x3,1);
    g = zeros(1,nObj);
    for i = 1:nObj
        g(i) = 0.0;
        len = sum(~isnan(x3(i,:)));
        for j = 1:len
           if isnan(x3(i,j))
               continue;
           end
           linkages  = sin(6*3.141592653589793*x1(1) + (index(i,j)*3.141592653589793)/D);
           g(i) = g(i) + (x3(i,j) - linkages)^2;
        end
        g(i) = 2 * g(i) /len;
    end
end

function g = getLF8(x1,x3,index,D)
    nObj = size(x3,1);
    g = zeros(1,nObj);
    for i = 1:nObj
        g(i) = 0.0;
        len = sum(~isnan(x3(i,:)));
        for j = 1:len
           if isnan(x3(i,j))
               continue;
           end
           linkages = 0.8 * x1(1) * cos(6*3.141592653589793*x1(1) + (index(i,j)*3.141592653589793)/D);
           g(i) = g(i) + (x3(i,j) - linkages)^2;
        end
        g(i) = 2 * g(i) /len;
    end
end

function g = getLF9(x1,x3,index,D)
    nObj = size(x3,1);
    g = zeros(1,nObj);
    for i = 1:nObj
        g(i) = 0.0;
        len = sum(~isnan(x3(i,:)));
        for j = 1:len
           if isnan(x3(i,j))
               continue;
           end
           linkages = 0.8 * x1(1) * sin(6*3.141592653589793*x1(1) + (index(i,j)*3.141592653589793)/D);
           g(i) = g(i) + (x3(i,j) - linkages)^2;
        end
        g(i) = 2 * g(i) /len;
    end
end

function g = getHF1(x)
   p = [0.3,0.3,0.4];
   n1 = ceil(p(1) * length(x));
   n2 = ceil(p(1) * length(x));
   n3 = length(x)-n1-n2;
   
   x1 = x(1:n1);
   x2 = x(n1+1:n1+n2);
   x3 = x(n1+n2+1:end);
   
   g = getCigar(x1) + getRastrigin(x2) + getMSchwefel(x3);
end

function g = getHF2(x)
   p = [0.3,0.3,0.4];
   n1 = ceil(p(1) * length(x));
   n2 = ceil(p(1) * length(x));
   n3 = length(x)-n1-n2;
   x1 = x(1:n1);
   x2 = x(n1+1:n1+n2);
   x3 = x(n1+n2+1:end);
   g = getRosenbrock(x1) + getWeierstrass(x2) + getGriewank(x3);
end

function g = getDF1(x1,xII,Task)
    if strcmp(Task.linkageType, 'linear')
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    xII{i}(j,k) =(1.0 + (Task.dgd{i}(j,k)+1.0)/(Task.dim))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    else
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    %java��PT = 3.141592653589793
                    xII{i}(j,k) =(1.0 + cos(0.5*3.14159265359*(Task.dgd{i}(j,k)+1.0)/(Task.dim)))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    end
    numObj = length(xII);
    g = zeros(1,numObj);
    for i = 1:numObj
       g(i) = 0;
       for j = 1:size(xII{i},1)
          temp = xII{i}(j,:);
          temp(temp==0)=[];
          g(i) = g(i) +  getSphere(temp);
       end
       g(i) = g(i)/size(xII{i},1);
    end
end

function g = getDF2(x1,xII,Task)
    if strcmp(Task.linkageType, 'linear')
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    xII{i}(j,k) =(1.0 + (Task.dgd{i}(j,k)+1.0)/(Task.dim))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    else
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    %java��PT = 3.141592653589793
                    xII{i}(j,k) =(1.0 + cos(0.5*3.14159265359*(Task.dgd{i}(j,k)+1.0)/(Task.dim)))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    end
    numObj = length(xII);
    g = zeros(1,numObj);
    for i = 1:numObj
       g(i) = 0;
       for j = 1:size(xII{i},1)
          temp = xII{i}(j,:);
          temp(temp==0)=[];
          g(i) = g(i) +  getMean(temp);
       end
       g(i) = g(i)/size(xII{i},1);
    end
end


function g = getDF14(x1,xII,Task)
    if strcmp(Task.linkageType, 'linear')
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    xII{i}(j,k) =(1.0 + (Task.dgd{i}(j,k)+1.0)/(Task.dim))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    else
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    %java��PT = 3.141592653589793
                    xII{i}(j,k) =(1.0 + cos(0.5*3.14159265359*(Task.dgd{i}(j,k)+1.0)/(Task.dim)))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    end
    numObj = length(xII);
    g = zeros(1,numObj);
    for i = 1:numObj
       g(i) = 0;
       for j = 1:size(xII{i},1)
          temp = xII{i}(j,:);
          temp(temp==0)=[];
          g(i) = g(i) +  getRosenbrock(temp);
       end
       g(i) = g(i)/size(xII{i},1);
    end
end

function g = getDF15(x1,xII,Task)
    if strcmp(Task.linkageType, 'linear')
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    xII{i}(j,k) =(1.0 + (Task.dgd{i}(j,k)+1.0)/(Task.dim))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    else
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    %java��PT = 3.141592653589793
                     xII{i}(j,k) =(1.0 + cos(0.5*3.14159265359*(Task.dgd{i}(j,k)+1.0)/(Task.dim)))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    end
    numObj = length(xII);
    g = zeros(1,numObj);
    for i = 1:numObj
       g(i) = 0;
       for j = 1:size(xII{i},1)
          temp = xII{i}(j,:);
          temp(temp==0)=[];
          g(i) = g(i) +  getAckley(temp);
       end
       g(i) = g(i)/size(xII{i},1);
    end
end

function g = getDF16(x1,xII,Task)
    if strcmp(Task.linkageType, 'linear')
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    xII{i}(j,k) =(1.0 + (Task.dgd{i}(j,k)+1.0)/(Task.dim))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    else
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    %java��PT = 3.141592653589793
                     xII{i}(j,k) =(1.0 + cos(0.5*3.14159265359*(Task.dgd{i}(j,k)+1.0)/(Task.dim)))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    end
    numObj = length(xII);
    g = zeros(1,numObj);
    for i = 1:numObj
       g(i) = 0;
       for j = 1:size(xII{i},1)
          temp = xII{i}(j,:);
          temp(temp==0)=[];
          g(i) = g(i) +  getWeierstrass(temp);
       end
       g(i) = g(i)/size(xII{i},1);
    end
end

function g = getDF17(x1,xII,Task)
    if strcmp(Task.linkageType, 'linear')
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    xII{i}(j,k) =(1.0 + (Task.dgd{i}(j,k)+1.0)/(Task.dim))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    else
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    %java��PT = 3.141592653589793
                     xII{i}(j,k) =(1.0 + cos(0.5*3.14159265359*(Task.dgd{i}(j,k)+1.0)/(Task.dim)))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    end
    numObj = length(xII);
    g = zeros(1,numObj);
    for i = 1:numObj
       g(i) = 0;
       for j = 1:size(xII{i},1)
          temp = xII{i}(j,:);
          temp(temp==0)=[];
          g(i) = g(i) +  getGriewank(temp);
       end
       g(i) = g(i)/size(xII{i},1);
    end
end

function g = getDF18(x1,xII,Task)
    if strcmp(Task.linkageType, 'linear')
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    xII{i}(j,k) =(1.0 + (Task.dgd{i}(j,k)+1.0)/(Task.dim))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    else
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    %java��PT = 3.141592653589793
                     xII{i}(j,k) =(1.0 + cos(0.5*3.14159265359*(Task.dgd{i}(j,k)+1.0)/(Task.dim)))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    end
    numObj = length(xII);
    g = zeros(1,numObj);
    for i = 1:numObj
       g(i) = 0;
       for j = 1:size(xII{i},1)
          temp = xII{i}(j,:);
          temp(temp==0)=[];
          g(i) = g(i) +  getRastrigin(temp);
       end
       g(i) = g(i)/size(xII{i},1);
    end
end

function g = getDF19(x1,xII,Task)
    if strcmp(Task.linkageType, 'linear')
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    xII{i}(j,k) =(1.0 + (Task.dgd{i}(j,k)+1.0)/(Task.dim))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    else
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    %java��PT = 3.141592653589793
                    xII{i}(j,k) =(1.0 + cos(0.5*3.14159265359*(Task.dgd{i}(j,k)+1.0)/(Task.dim)))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    end
    numObj = length(xII);
    g = zeros(1,numObj);
    for i = 1:numObj
       g(i) = 0;
       for j = 1:size(xII{i},1)
          temp = xII{i}(j,:);
          temp(temp==0)=[];
          g(i) = g(i) +  getElliptic(temp);
       end
       g(i) = g(i)/size(xII{i},1);
    end
end

function g = getDF20(x1,xII,Task)
    if strcmp(Task.linkageType, 'linear')
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    xII{i}(j,k) =(1.0 + (Task.dgd{i}(j,k)+1.0)/(Task.dim))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    else
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    %java��PT = 3.141592653589793
                    xII{i}(j,k) =(1.0 + cos(0.5*3.14159265359*(Task.dgd{i}(j,k)+1.0)/(Task.dim)))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    end
    numObj = length(xII);
    g = zeros(1,numObj);
    for i = 1:numObj
       g(i) = 0;
       for j = 1:size(xII{i},1)
          temp = xII{i}(j,:);
          temp(temp==0)=[];
          g(i) = g(i) +  getCigar(temp);
       end
       g(i) = g(i)/size(xII{i},1);
    end
end

function g = getDF21(x1,xII,Task)
    if strcmp(Task.linkageType, 'linear')
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    xII{i}(j,k) =(1.0 + (Task.dgd{i}(j,k)+1.0)/(Task.dim))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    else
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    %java��PT = 3.141592653589793
                    xII{i}(j,k) =(1.0 + cos(0.5*3.14159265359*(Task.dgd{i}(j,k)+1.0)/(Task.dim)))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    end
    numObj = length(xII);
    g = zeros(1,numObj);
    for i = 1:numObj
       g(i) = 0;
       for j = 1:size(xII{i},1)
          temp = xII{i}(j,:);
          temp(temp==0)=[];
          g(i) = g(i) +  getDiscus(temp);
       end
       g(i) = g(i)/size(xII{i},1);
    end
end

function g = getDF22(x1,xII,Task)
    if strcmp(Task.linkageType, 'linear')
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    xII{i}(j,k) =(1.0 + (Task.dgd{i}(j,k)+1.0)/(Task.dim))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    else
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    %java��PT = 3.141592653589793
                    xII{i}(j,k) =(1.0 + cos(0.5*3.14159265359*(Task.dgd{i}(j,k)+1.0)/(Task.dim)))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    end
    numObj = length(xII);
    g = zeros(1,numObj);
    for i = 1:numObj
       g(i) = 0;
       for j = 1:size(xII{i},1)
          temp = xII{i}(j,:);
          temp(temp==0)=[];
          g(i) = g(i) +  getMSchwefel(temp);
       end
       g(i) = g(i)/size(xII{i},1);
    end
end

function g = getDF23(x1,xII,Task)
    if strcmp(Task.linkageType, 'linear')
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    xII{i}(j,k) =(1.0 + (Task.dgd{i}(j,k)+1.0)/(Task.dim))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    else
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    %java��PT = 3.141592653589793
                    xII{i}(j,k) =(1.0 + cos(0.5*3.14159265359*(Task.dgd{i}(j,k)+1.0)/(Task.dim)))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    end
    numObj = length(xII);
    g = zeros(1,numObj);
    for i = 1:numObj
       g(i) = 0;
       for j = 1:size(xII{i},1)
          temp = xII{i}(j,:);
          temp(temp==0)=[];
          g(i) = g(i) +  getKatsuura(temp);
       end
       g(i) = g(i)/size(xII{i},1);
    end
end

function g = getDF24(x1,xII,Task)
    if strcmp(Task.linkageType, 'linear')
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    xII{i}(j,k) =(1.0 + (Task.dgd{i}(j,k)+1.0)/(Task.dim))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    else
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    %java��PT = 3.141592653589793
                    xII{i}(j,k) =(1.0 + cos(0.5*3.14159265359*(Task.dgd{i}(j,k)+1.0)/(Task.dim)))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    end
    numObj = length(xII);
    g = zeros(1,numObj);
    for i = 1:numObj
       g(i) = 0;
       for j = 1:size(xII{i},1)
          temp = xII{i}(j,:);
          temp(temp==0)=[];
          g(i) = g(i) +  getHappyCat(temp);
       end
       g(i) = g(i)/size(xII{i},1);
    end
end

function g = getDF25(x1,xII,Task)
    if strcmp(Task.linkageType, 'linear')
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    xII{i}(j,k) =(1.0 + (Task.dgd{i}(j,k)+1.0)/(Task.dim))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    else
        for i=1:length(xII)
            for j=1:size(xII{i},1)
                temp = find(xII{i}(j,:) ~=0 );  %ȥ��Ϊ0��Ԫ��
                for k=1:length(temp)
                    %java��PT = 3.141592653589793
                    xII{i}(j,k) =(1.0 + cos(0.5*3.14159265359*(Task.dgd{i}(j,k)+1.0)/(Task.dim)))*xII{i}(j,k)- 10.0*x1;
                end
            end
        end
    end
    numObj = length(xII);
    g = zeros(1,numObj);
    for i = 1:numObj
       g(i) = 0;
       for j = 1:size(xII{i},1)
          temp = xII{i}(j,:);
          temp(temp==0)=[];
          g(i) = g(i) +  getExGriewRosen(temp);
       end
       g(i) = g(i)/size(xII{i},1);
    end
end


function Hvalue = evalH(x1,Task)
    obj_num = Task.numberOfObjectives;
    h = zeros(1,obj_num);
    if obj_num == 2
        if strcmp(Task.hType, 'convex')
            h(1) = x1(1);
            h(2) = 1 - x1(1)^0.5;
        elseif strcmp(Task.hType, 'concave')
            h(1) = x1(1);
            h(2) = 1 - x1(1)^2;
        elseif strcmp(Task.hType, 'lineoid')
            h(1) = x1(1);
            h(2) = 1 - x1(1);
        end
    elseif obj_num >= 3
        if strcmp(Task.hType, 'sphere')
            for i = 1:obj_num
               h(i) = 1.0;
               for j = 1:obj_num - i
                  h(i) =  h(i) * cos(x1(j)*0.5*3.141592653589793);
               end
               if i ~= 1
                   aux = obj_num - i + 1;
                   h(i) = h(i) * sin(x1(aux)*0.5*3.141592653589793);
               end
            end
        %else
        end
    end

    Hvalue = h;
end

function Hvalue = evalH2(x1,g,Task)
    Hvalue = zeros(1,Task.numberOfObjectives);
    if strcmp(Task.hType, 'lineoid')
        for i = 1:Task.numberOfObjectives
            Hvalue(i) = 1.0;
            for j = 1:Task.numberOfObjectives - i
                Hvalue(i) = Hvalue(i) * x1(j);
            end
            if i~= 1
                aux = Task.numberOfObjectives - i + 1;
                Hvalue(i) = Hvalue(i) * (1 - x1(aux));
            end
        end
    elseif strcmp(Task.hType, 'circle') || strcmp(Task.hType, 'sphere')
        for i = 1:Task.numberOfObjectives
            Hvalue(i) = 1.0;
            for j = 1:Task.numberOfObjectives - i
                Hvalue(i) = Hvalue(i)* cos(x1(j)*0.5 * 3.141592653589793);
            end
            if i~=1
               aux =  Task.numberOfObjectives - i + 1;
               Hvalue(i) = Hvalue(i)* sin(x1(aux) * 0.5 * 3.141592653589793 );
            end
        end        
    elseif strcmp(Task.hType, 'convex')
        for i = 1:Task.numberOfObjectives
            Hvalue(i) = 1.0;
            for j = 1:Task.numberOfObjectives - i
                Hvalue(i) = Hvalue(i) * cos(x1(j)*0.5*3.141592653589793);
            end
            if i~=1
               aux =  Task.numberOfObjectives - i + 1;
               Hvalue(i) = Hvalue(i) * sin(x1(aux) * 0.5 * 3.141592653589793);
            end
            if i~= Task.numberOfObjectives
                Hvalue(i) = power(Hvalue(i),4);
            else
                Hvalue(i) = power(Hvalue(i),2);
            end
        end
    end
end

function Hfunction = evalHMMLMOP(Task , xI)
    h = zeros(1,Task.numberOfObjectives);
    if strcmp(Task.hType, 'lineoid')
        for i = 1:Task.numberOfObjectives
			h(i) = 1.0;
            for j = 1:Task.numberOfObjectives - i
                h(i) = h(i) * xI(j);
            end
            if i ~= 1
                aux = Task.numberOfObjectives - i;  %aux�п���ȡ��0
                h(i) = h(i) * (1 - xI(aux+1));
            end
        end
    elseif strcmp(Task.hType, 'inverted_lineoid')
        for i = 1:Task.numberOfObjectives
            h(i) = 1.0;
            for j = 1:Task.numberOfObjectives - i
                h(i) = h(i) * xI(j);
            end
            if  i ~= 1
                aux = Task.numberOfObjectives - i;
                h(i) = h(i) * (1 - xI(aux+1));
            end
            h(i) = 1.0 - h(i);
        end
    elseif strcmp(Task.hType, 'circle')||strcmp(Task.hType, 'sphere')
         for i = 1:Task.numberOfObjectives
            h(i) = 1.0;
            for j = 1:Task.numberOfObjectives - i
                h(i) = h(i) * cos(xI(j) * 0.5 * 3.14159265359);
            end
            if i~=1
               aux = Task.numberOfObjectives - i + 1;
               h(i) = h(i) * sin(xI(aux) * 0.5 * 3.14159265359);
            end
         end
    elseif strcmp(Task.hType, 'convex')
        for i = 1:Task.numberOfObjectives
            h(i) = 1.0;
            for j = 1:Task.numberOfObjectives - i
                h(i) = h(i) * cos(xI(j) * 0.5 * 3.14159265359);
            end
            if i~=1
               aux = Task.numberOfObjectives - i + 1;
               h(i) = h(i) * sin(xI(aux) * 0.5 * 3.14159265359);
            end
            if i~=Task.numberOfObjectives
                h(i) = h(i)^4;
            else
                h(i) = h(i)^2;
            end
         end
    end
    Hfunction = h;
end

function Hvalue = evalHMMIDTLZ(Task,x1)
    Hvalue = zeros(1,Task.numberOfObjectives);
    if strcmp(Task.hType, 'inverted_lineoid')
        for i = 1:Task.numberOfObjectives
           Hvalue(i) = 1;
           for j = 1:Task.numberOfObjectives - i
               Hvalue(i) = Hvalue(i) * x1(j);
           end
           if i ~= 1
              aux =  Task.numberOfObjectives - i + 1;
              Hvalue(i) = Hvalue(i) * (1 - x1(aux));
           end
           Hvalue(i) = 1 - Hvalue(i);
        end
    elseif strcmp(Task.hType, 'inverted_sphere')
        for i = 1:Task.numberOfObjectives
           Hvalue(i) = 1;
           for j = 1:Task.numberOfObjectives - i
               Hvalue(i) = Hvalue(i) * cos(x1(j) *  0.5 * 3.141592653589793);
           end
           if i ~= 1
              aux =  Task.numberOfObjectives - i + 1;
              Hvalue(i) = Hvalue(i) * sin(x1(aux) * 0.5 * 3.141592653589793);
           end
           Hvalue(i) = 1 - Hvalue(i);
        end
    end
end
%��������
function value = getRosenbrock(x)
    sum = 0;
    for i = 1:length(x) - 1
        t = 100 * (x(i)^2 - x(i+1)) * (x(i)^2 - x(i+1)) + ( 1 - x(i)) ^2;
        sum = sum + t;
    end
    value = sum;
end

function value = getGriewank(x)
    k = 1;
    sum = 0;
    prod = 1;
    for i = 1:length(x)
       sum = sum + (x(i)^2);
       prod = prod * (k*cos(x(i) / sqrt(i)));
    end
    value = k + sum/4000 - prod;
end

function value = getWeierstrass(x)
    part1= 0.0; part2 = 0.0;
    a = 0.5; b = 3.0;k = 20.0;
    w = 2 * 3.141592653589793;

    for i = 1:length(x)
       for j = 1:k
           part1 = part1 + power(a,j-1) * cos(w * power(b,j-1)*(x(i) + 0.5));
       end
    end
    for j = 1:k+1
         part2 = part2 + power(a,j-1) * cos(w * power(b,j-1)* 0.5);
    end
    value = part1 - length(x) * part2;
end

function value = getCigar(x)
    sum = 0;
    for i = 2:length(x)
       sum = sum + x(i)^2; 
    end
    value = power(x(1),2) + power(10,6) * sum;
end

function value = getRastrigin(x)
    result = 0;
    a = 10.0;
    w = 2 * 3.141592653589793;
    for i = 1:length(x)
       result  = result + x(i)^2 - a * cos(w*x(i)); 
    end
    result = result + a*length(x);
    value = result;
end

function value = getMSchwefel(x)
    sum = 0;
    thisDim = length(x);
    z = zeros(1,thisDim);
    gz = zeros(1,thisDim);
    
    for i = 1:thisDim
        z(i) = x(i) + 4.209687462275036e+002;
        if abs(z(i))<=500
            gz(i) = z(i) * sin(power(abs(z(i)),0.5));
        elseif z(i)> 500
            gz(i) = mod((500-z(i)),500) * sin(power(abs(mod(500-z(i),500)),0.5)) - power(z(i)-500,2)/(10000*thisDim);
        else
%             gz[i]=(Math.abs(z[i])%500-500)*Math.sin(Math.pow(500-Math.abs(z[i])%500, 0.5))   -Math.pow(z[i]+500,2)/(10000*dim);
            gz(i)=(mod(abs(z(i)),500)-500) * sin(power(500-mod(abs(z(i)),500),0.5))- power(z(i)+500,2)/(10000*thisDim);
        end
        sum = sum + gz(i);
    end
    sum=418.9829*thisDim-sum;
    value = sum;
end

function value = getAckley(x)
    sum1 = 0;
    sum2 = 0;
    for i = 1:length(x)
        sum1 = sum1 + (x(i)^2)/length(x);
        sum2 = sum2 + cos(2*3.141592653589793*x(i))/length(x);
    end
    value = -20 * exp( -0.2 * sqrt(sum1)) - exp(sum2) + 20 + 2.718282;
end

function value = getSphere(x)
    sum = 0;
    for i = 1:length(x)
       sum = sum + x(i)^2; 
    end
    value = sum;
end

function value = getElliptic(x)
    sum = 0;
    dim = length(x);
    a = power(10,6);
    for i = 1:dim
       sum = sum + power(a,(i-1)/(dim - 1.0))*(x(i)*x(i)); 
    end
    value = sum;
end

function value = getDiscus(x)
    sum = 0;
    for i = 2:length(x)
        sum = sum + x(i)^2;
    end
    value = power(10,6)*power(x(1),2) + sum;
end

function value = getKatsuura(x)
    index = 32;
    dim = length(x);
    sum = 0;
    prod = 1;
    for i = 1:dim
       for j = 1:index
           sum = sum + abs(power(2,j)*x(i) - round(power(2,j)*x(i)))/power(2,j);
       end
       prod = prod * power(1+(i-1)*sum,10/power(dim,1.2));
    end
    value = 10/power(dim,1.2)*prod - 10 /power(dim,1.2);
end

function value = getHappyCat(x)
    sum1 = 0;
    sum2 = 0;
    dim = length(x);
    for i = 1:dim
       x(i) = x(i) - 1;
       sum1 = sum1 + (x(i)*x(i));
       sum2 = sum2 + x(i);
    end
    value = power(abs(sum1-dim),0.25) + (0.5*sum1 + sum2)/dim + 0.5;
end

function value = getMean(x)
    sum = 0;
    for i = 1:length(x)
        sum = sum + abs(x(i))*9;
    end
    value = sum/length(x);
end

function value = getExGriewRosen(x)
    sum = 0;
    dim = length(x);
    x(1) = x(1) + 1;
    
    for i = 1:dim - 1
       x(i+1)  = x(i+1) + 1;
       tmp1 = x(i)*x(i) - x(i+1);
       tmp2 = x(i) - 1;
       temp = 100*tmp1*tmp1 + tmp2*tmp2;
       sum = sum + (temp*temp)/4000 - cos(temp) + 1.0;
    end
    tmp1 = x(dim)^2 - x(1);
    tmp2 = x(dim) - 1;
    temp = 100*tmp1*tmp1 + tmp2*tmp2;
    sum = sum + (temp*temp)/4000 - cos(temp) + 1.0;
    value = sum;
end