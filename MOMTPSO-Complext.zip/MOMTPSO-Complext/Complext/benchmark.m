function [Tasks] = benchmark(benchMark_num)

switch benchMark_num
    case 1
        dim=50;
        %Task 1
        file_dir = strcat(".\MData\benchmark_", string(benchMark_num));
        shift_file = strcat("\bias_", string(1));
        rotation_file = strcat("\matrix_", string(1));
        Tasks(1).matrix = load(strcat(file_dir, rotation_file));
        Tasks(1).shift = load(strcat(file_dir, shift_file));
        Tasks(1).type='MMDTLZ';
        Tasks(1).Gfunction = 'F17';
        Tasks(1).boundaryCvDv = 1;
        Tasks(1).dim=dim;
        
        %Task 2
        file_dir = strcat(".\MData\benchmark_", string(benchMark_num));
        shift_file = strcat("\bias_", string(2));
        rotation_file = strcat("\matrix_", string(2));
        Tasks(2).matrix = load(strcat(file_dir, rotation_file));
        Tasks(2).shift = load(strcat(file_dir, shift_file));
        Tasks(2).type='MMZDT';
        Tasks(2).F1Function='linear';
        Tasks(2).Gfunction = 'F17';
        Tasks(2).Hfunction = 'concave';
        Tasks(2).boundaryCvDv = 1;
        Tasks(2).dim=dim;
        
        Low = -100 .* ones(1 , 49);
        Upper = 100 .* ones(1 , 49);
        Tasks(1).Low = [0 , Low];
        Tasks(1).Upper = [1 , Upper];
        Tasks(2).Low = [0 , Low];
        Tasks(2).Upper = [1 , Upper];
    case 2
        dim=50;
        %Task 1
        file_dir = strcat(".\MData\benchmark_", string(benchMark_num));
        shift_file = strcat("\bias_", string(1));
        rotation_file = strcat("\matrix_", string(1));
        Tasks(1).matrix = load(strcat(file_dir, rotation_file));
        Tasks(1).shift = load(strcat(file_dir, shift_file));
        Tasks(1).type='MMDTLZ';
        Tasks(1).Gfunction = 'F19';
        Tasks(1).boundaryCvDv = 1;
        Tasks(1).dim=dim;
        
        %Task 2
        file_dir = strcat(".\MData\benchmark_", string(benchMark_num));
        shift_file = strcat("\bias_", string(2));
        rotation_file = strcat("\matrix_", string(2));
        Tasks(2).matrix = load(strcat(file_dir, rotation_file));
        Tasks(2).shift = load(strcat(file_dir, shift_file));
        Tasks(2).type='MMDTLZ';
        Tasks(2).Gfunction = 'F19';
        Tasks(2).boundaryCvDv = 1;
        Tasks(2).dim=dim;
        
        Low = -100 .* ones(1 , 49);
        Upper = 100 .* ones(1 , 49);
        Tasks(1).Low = [0 , Low];
        Tasks(1).Upper = [1 , Upper];
        Tasks(2).Low = [0 , Low];
        Tasks(2).Upper = [1 , Upper];
    case 3
        dim=50;
        file_dir = strcat(".\MData\benchmark_", string(benchMark_num));
        shift_file = strcat("\bias_", string(1));
        rotation_file = strcat("\matrix_", string(1));
        Tasks(1).matrix = load(strcat(file_dir, rotation_file));
        Tasks(1).shift = load(strcat(file_dir, shift_file));
        Tasks(1).type='MMDTLZ';
        Tasks(1).Gfunction = 'F22';
        Tasks(1).boundaryCvDv = 1;
        Tasks(1).dim=dim;
        
        %Task 2
        file_dir = strcat(".\MData\benchmark_", string(benchMark_num));
        shift_file = strcat("\bias_", string(2));
        rotation_file = strcat("\matrix_", string(2));
        Tasks(2).matrix = load(strcat(file_dir, rotation_file));
        Tasks(2).shift = load(strcat(file_dir, shift_file));
        Tasks(2).type='MMZDT';
        Tasks(2).F1Function='linear';
        Tasks(2).Gfunction = 'F22';
        Tasks(2).Hfunction = 'convex';
        Tasks(2).boundaryCvDv = 1;
        Tasks(2).dim=dim;
        
        Low = -100 .* ones(1 , 49);
        Upper = 100 .* ones(1 , 49);
        Tasks(1).Low = [0 , Low];
        Tasks(1).Upper = [1 , Upper];
        Tasks(2).Low = [0 , Low];
        Tasks(2).Upper = [1 , Upper];
    case 4
        dim=50;
        %Task 1
        file_dir = strcat(".\MData\benchmark_", string(benchMark_num));
        shift_file = strcat("\bias_", string(1));
        rotation_file = strcat("\matrix_", string(1));
        Tasks(1).matrix = load(strcat(file_dir, rotation_file));
        Tasks(1).shift = load(strcat(file_dir, shift_file));
        Tasks(1).type='MMZDT';
        Tasks(1).F1Function='linear';
        Tasks(1).Gfunction = 'F15';
        Tasks(1).Hfunction = 'convex';
        Tasks(1).boundaryCvDv = 1;
        Tasks(1).dim=dim;
        
        %Task 2
        file_dir = strcat(".\MData\benchmark_", string(benchMark_num));
        shift_file = strcat("\bias_", string(2));
        rotation_file = strcat("\matrix_", string(2));
        Tasks(2).matrix = load(strcat(file_dir, rotation_file));
        Tasks(2).shift = load(strcat(file_dir, shift_file));
        Tasks(2).type='MMZDT';
        Tasks(2).F1Function='linear';
        Tasks(2).Gfunction = 'F15';
        Tasks(2).Hfunction = 'convex';
        Tasks(2).boundaryCvDv = 1;
        Tasks(2).dim=dim;
        
        Low = -100 .* ones(1 , 49);
        Upper = 100 .* ones(1 , 49);
        Tasks(1).Low = [0 , Low];
        Tasks(1).Upper = [1 , Upper];
        Tasks(2).Low = [0 , Low];
        Tasks(2).Upper = [1 , Upper];
    case 5
        dim=50;
        %Task 1
        file_dir = strcat(".\MData\benchmark_", string(benchMark_num));
        shift_file = strcat("\bias_", string(1));
        rotation_file = strcat("\matrix_", string(1));
        Tasks(1).matrix = load(strcat(file_dir, rotation_file));
        Tasks(1).shift = load(strcat(file_dir, shift_file));
        Tasks(1).type='MMDTLZ';
        Tasks(1).Gfunction = 'F4';
        Tasks(1).boundaryCvDv = 1;
        Tasks(1).dim=dim;
        
        %Task 2
        file_dir = strcat(".\MData\benchmark_", string(benchMark_num));
        shift_file = strcat("\bias_", string(2));
        rotation_file = strcat("\matrix_", string(2));
        Tasks(2).matrix = load(strcat(file_dir, rotation_file));
        Tasks(2).shift = load(strcat(file_dir, shift_file));
        Tasks(2).type='MMZDT';
        Tasks(2).F1Function='linear';
        Tasks(2).Gfunction = 'F4';
        Tasks(2).Hfunction = 'concave';
        Tasks(2).boundaryCvDv = 1;
        Tasks(2).dim=dim;
        
        Low = -100 .* ones(1 , 49);
        Upper = 100 .* ones(1 , 49);
        Tasks(1).Low = [0 , Low];
        Tasks(1).Upper = [1 , Upper];
        Tasks(2).Low = [0 , Low];
        Tasks(2).Upper = [1 , Upper];
    case 6
        dim=50;
        %Task 1
        file_dir = strcat(".\MData\benchmark_", string(benchMark_num));
        shift_file = strcat("\bias_", string(1));
        rotation_file = strcat("\matrix_", string(1));
        Tasks(1).matrix = load(strcat(file_dir, rotation_file));
        Tasks(1).shift = load(strcat(file_dir, shift_file));
        Tasks(1).type='MMDTLZ';
        Tasks(1).Gfunction = 'F9';
        Tasks(1).boundaryCvDv = 1;
        Tasks(1).dim=dim;
        
        %Task 2
        file_dir = strcat(".\MData\benchmark_", string(benchMark_num));
        shift_file = strcat("\bias_", string(2));
        rotation_file = strcat("\matrix_", string(2));
        Tasks(2).matrix = load(strcat(file_dir, rotation_file));
        Tasks(2).shift = load(strcat(file_dir, shift_file));
        Tasks(2).type='MMDTLZ';
        Tasks(2).Gfunction = 'F9';
        Tasks(2).boundaryCvDv = 1;
        Tasks(2).dim=dim;
        
        Low = -100 .* ones(1 , 49);
        Upper = 100 .* ones(1 , 49);
        Tasks(1).Low = [0 , Low];
        Tasks(1).Upper = [1 , Upper];
        Tasks(2).Low = [0 , Low];
        Tasks(2).Upper = [1 , Upper];
    case 7
        dim=50;
        %Task 1
        file_dir = strcat(".\MData\benchmark_", string(benchMark_num));
        shift_file = strcat("\bias_", string(1));
        rotation_file = strcat("\matrix_", string(1));
        Tasks(1).matrix = load(strcat(file_dir, rotation_file));
        Tasks(1).shift = load(strcat(file_dir, shift_file));
        Tasks(1).type='MMDTLZ';
        Tasks(1).Gfunction = 'F8';
        Tasks(1).boundaryCvDv = 1;
        Tasks(1).dim=dim;
        
        %Task 2
        file_dir = strcat(".\MData\benchmark_", string(benchMark_num));
        shift_file = strcat("\bias_", string(2));
        rotation_file = strcat("\matrix_", string(2));
        Tasks(2).matrix = load(strcat(file_dir, rotation_file));
        Tasks(2).shift = load(strcat(file_dir, shift_file));
        Tasks(2).type='MMZDT';
        Tasks(2).F1Function='linear';
        Tasks(2).Gfunction = 'F8';
        Tasks(2).Hfunction = 'convex';
        Tasks(2).boundaryCvDv = 1;
        Tasks(2).dim=dim;
        
        Low = -100 .* ones(1 , 49);
        Upper = 100 .* ones(1 , 49);
        Tasks(1).Low = [0 , Low];
        Tasks(1).Upper = [1 , Upper];
        Tasks(2).Low = [0 , Low];
        Tasks(2).Upper = [1 , Upper];
    case 8
        dim=50;
        %Task 1
        file_dir = strcat(".\MData\benchmark_", string(benchMark_num));
        shift_file = strcat("\bias_", string(1));
        rotation_file = strcat("\matrix_", string(1));
        Tasks(1).matrix = load(strcat(file_dir, rotation_file));
        Tasks(1).shift = load(strcat(file_dir, shift_file));
        Tasks(1).type='MMDTLZ';
        Tasks(1).Gfunction = 'F18';
        Tasks(1).boundaryCvDv = 1;
        Tasks(1).dim=dim;
        
        %Task 2
        file_dir = strcat(".\MData\benchmark_", string(benchMark_num));
        shift_file = strcat("\bias_", string(2));
        rotation_file = strcat("\matrix_", string(2));
        Tasks(2).matrix = load(strcat(file_dir, rotation_file));
        Tasks(2).shift = load(strcat(file_dir, shift_file));
        Tasks(2).type='MMZDT';
        Tasks(2).F1Function='linear';
        Tasks(2).Gfunction = 'F20';
        Tasks(2).Hfunction = 'concave';
        Tasks(2).boundaryCvDv = 1;
        Tasks(2).dim=dim;
        
        Low = -100 .* ones(1 , 49);
        Upper = 100 .* ones(1 , 49);
        Tasks(1).Low = [0 , Low];
        Tasks(1).Upper = [1 , Upper];
        Tasks(2).Low = [0 , Low];
        Tasks(2).Upper = [1 , Upper];
    case 9
        dim=50;
        %Task 1
        file_dir = strcat(".\MData\benchmark_", string(benchMark_num));
        shift_file = strcat("\bias_", string(1));
        rotation_file = strcat("\matrix_", string(1));
        Tasks(1).matrix = load(strcat(file_dir, rotation_file));
        Tasks(1).shift = load(strcat(file_dir, shift_file));
        Tasks(1).type='MMDTLZ';
        Tasks(1).Gfunction = 'F11';
        Tasks(1).boundaryCvDv = 1;
        Tasks(1).dim=dim;
        
        %Task 2
        file_dir = strcat(".\MData\benchmark_", string(benchMark_num));
        shift_file = strcat("\bias_", string(2));
        rotation_file = strcat("\matrix_", string(2));
        Tasks(2).matrix = load(strcat(file_dir, rotation_file));
        Tasks(2).shift = load(strcat(file_dir, shift_file));
        Tasks(2).type='MMZDT';
        Tasks(2).F1Function='linear';
        Tasks(2).Gfunction = 'F18';
        Tasks(2).Hfunction = 'concave';
        Tasks(2).boundaryCvDv = 1;
        Tasks(2).dim=dim;
        
        Low = -100 .* ones(1 , 49);
        Upper = 100 .* ones(1 , 49);
        Tasks(1).Low = [0 , Low];
        Tasks(1).Upper = [1 , Upper];
        Tasks(2).Low = [0 , Low];
        Tasks(2).Upper = [1 , Upper];
    case 10
        dim=50;
        %Task 1
        file_dir = strcat(".\MData\benchmark_", string(benchMark_num));
        shift_file = strcat("\bias_", string(1));
        rotation_file = strcat("\matrix_", string(1));
        Tasks(1).matrix = load(strcat(file_dir, rotation_file));
        Tasks(1).shift = load(strcat(file_dir, shift_file));
        Tasks(1).type='MMDTLZ';
        Tasks(1).Gfunction = 'F15';
        Tasks(1).boundaryCvDv = 1;
        Tasks(1).dim=dim;
        
        %Task 2
        file_dir = strcat(".\MData\benchmark_", string(benchMark_num));
        shift_file = strcat("\bias_", string(2));
        rotation_file = strcat("\matrix_", string(2));
        Tasks(2).matrix = load(strcat(file_dir, rotation_file));
        Tasks(2).shift = load(strcat(file_dir, shift_file));
        Tasks(2).type='MMZDT';
        Tasks(2).F1Function='linear';
        Tasks(2).Gfunction = 'F17';
        Tasks(2).Hfunction = 'concave';
        Tasks(2).boundaryCvDv = 1;
        Tasks(2).dim=dim;
        
        Low = -100 .* ones(1 , 49);
        Upper = 100 .* ones(1 , 49);
        Tasks(1).Low = [0 , Low];
        Tasks(1).Upper = [1 , Upper];
        Tasks(2).Low = [0 , Low];
        Tasks(2).Upper = [1 , Upper];
end
end

