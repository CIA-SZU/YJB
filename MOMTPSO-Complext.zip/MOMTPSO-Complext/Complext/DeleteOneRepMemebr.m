function rep=DeleteOneRepMemebr(rep)
    
    front(1) = numel(rep); 
    [rep,~]=SolutionComparison.diversity(rep,front,length(rep),length(rep(1).obj));
    rep(end) = [];
%     % Grid Index of All Repository Members
%     GI=[rep.GridIndex];
%     
%     % Occupied Cells
%     OC=unique(GI);
%     
%     % Number of Particles in Occupied Cells
%     N=zeros(size(OC));
%     for k=1:numel(OC)
%         N(k)=numel(find(GI==OC(k)));   
%     end
%     
%     %��ɾ���ĸ��ʸ�Ϊÿ�����ӵı�ɾ���ĸ���
%     P=exp(N);            
%     P=P/sum(P);
%     
%     sci=RouletteWheelSelection(P);
%     sc=OC(sci);

%     SCM=find(GI==sc);     
%     
%      if length(SCM)==1
%             rep(SCM) = [];      %���������
%      else
%         distance=[];
%         for i=1:numel(SCM)
%             t = SCM(i);
%             distance(i)=sqrt(rep(t).pbestFitness(1)^2+rep(t).pbestFitness(2)^2);
%         end
%         
%         %����ɾ�����������Ǹ�
%         maxF=max(distance);
%         minF=min(distance);
%         
%         for i=1:numel(SCM)
%             Chose(i) = exp(gamma*(distance(i)-minF)/(maxF-minF));
%         end
%         Chose = Chose/sum(Chose);
%         par = RouletteWheelSelection(Chose);  
%         rep(SCM(par)) = [];
%      end
 
end