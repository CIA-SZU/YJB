clear;
beep off
warning off
global evaluation
global maxevaluation
maxevaluation = 5e6;
evaluation = 0;
pop=5000;
rmp=0.5;
gen=1000;
for index =1:10
    Tasks=benchmark(index);
    for run=1:30
        pop = length(Tasks) * 100;
        [data_MFPSO{index,run},igd{index,run}]=MOMTPSO(Tasks,pop,gen,rmp,index);
        evaluation = 0;
    end
end

save('MOMTPSO-Complex','igd');
