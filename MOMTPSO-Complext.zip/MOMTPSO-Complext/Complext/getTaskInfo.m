function Task = getTaskInfo(Task,lg,up)
        number_nip = 3;             %�����ʱд��������
        nip = zeros(1,Task.numberOfObjectives-1);
        nop = zeros(1,Task.numberOfObjectives-1);
        sumNIP = 0;
        for i = 1:Task.numberOfObjectives-1
            nip(i) = number_nip;
            if Task.numberOfObjectives == 2
                nop(i) = 0;
            else
                nop(i) = 1;
            end
            sumNIP = sumNIP + nip(i);
        end
        nsp = 1;
        K = nsp + sumNIP;
        L = Task.dim - K;
        c = zeros(1,Task.numberOfObjectives);
        c(1) = 3.8 * 0.1 * (1.0 - 0.1);
        sumC = c(1);
        for i = 2:Task.numberOfObjectives
           c(i) =  3.8 * c(i-1) * (1.0 - c(i-1));
           sumC = sumC + c(i);
        end
        sumNID = 0;
        for i = 1:Task.numberOfObjectives
            nid(i) = floor(c(i)/sumC*L);
            sumNID = sumNID + nid(i);
        end
        nod = zeros(1,Task.numberOfObjectives);
        for i = 1:Task.numberOfObjectives
            if i == 1
                nod(i) = floor(nid(Task.numberOfObjectives)/5);
            else
                nod(i) = floor(nid(i-1)/5);
            end
        end
        nsd = L - sumNID;
        gp = overlapGrouping(nip, nop, nsp, Task.numberOfObjectives-1, 0);
		gd = overlapGrouping(nid, nod, nsd, Task.numberOfObjectives, K);
        for i = 1:Task.numberOfObjectives
           if mod(i,2) == 1
               dgd{i} = deepGrouping(gd(i,:), 4, 2);
           else
               dgd{i} = deepGrouping(gd(i,:), 4, 1);
           end
        end
        
        Task.Low = [-1*ones(1,K),lg * ones(1,Task.dim - K)];
        Task.Upper = [ones(1,K),up * ones(1,Task.dim - K)];
        Task.boundaryCvDv = K;
        Task.dgd = dgd;
        Task.matrix = eye(L);
        Task.shift = zeros(1,L);
        Task.gp = gp;
end